CREATE DATABASE Academie;

CREATE TABLE IF NOT EXISTS `COLLEGE`(
    `numCollege` INT(20) NOT NULL AUTO_INCREMENT,
    `nomCollege` VARCHAR(20) DEFAULT NULL,
    `siteInternet`VARCHAR(40) DEFAULT NULL,
    CONSTRAINT pk_numCollege PRIMARY KEY(`numCollege`)

);

CREATE TABLE IF NOT EXISTS `SALLE`(
    `numSalle` INT(20) NOT NULL AUTO_INCREMENT,
    `nomSalle` VARCHAR(20) DEFAULT NULL,
    `place` INT(30) DEFAULT NULL,
    CONSTRAINT pk_numSalle PRIMARY KEY(`numSalle`)
);

CREATE TABLE IF NOT EXISTS `FICHESIGNALETIQUE`(
    `numFiche` INT(20) NOT NULL AUTO_INCREMENT,
    `prenom` VARCHAR(20) DEFAULT NULL,
    `tel` VARCHAR(12) DEFAULT NULL,
    `mail` VARCHAR(20) DEFAULT NULL,
    CONSTRAINT pk_numFiche PRIMARY KEY(`numFiche`)
);

CREATE TABLE IF NOT EXISTS `ENSEIGNANT`(
    `Indice` INT(20) NOT NULL AUTO_INCREMENT,
    `nomEnseignant` VARCHAR(20) DEFAULT NULL,
    `prenomEnseignant` VARCHAR(20) DEFAULT NULL,
    `telEnseignant` VARCHAR(12) DEFAULT NULL,
    `mailEnseignant` VARCHAR(20) DEFAULT NULL,
    `datePriseFonction` DATE() DEFAULT NULL,
    `numFiche` INT(20) DEFAULT NULL,
    CONSTRAINT pk_Indice PRIMARY KEY(`Indice`),
    CONSTRAINT fk_numFiche FOREIGN KEY(`numFiche`) REFERENCES `FICHESIGNALETIQUE`(`numFiche`)

);

CREATE TABLE IF NOT EXISTS `DEPARTEMENT`(
    `numDepartement`INT(20) NOT NULL AUTO_INCREMENT,
    `nomDepartement`VARCHAR(20) DEFAULT NULL,
    `Indice`INT(20) DEFAULT NULL,
    CONSTRAINT pk_numDepartement PRIMARY KEY(`numDepartement`),
    CONSTRAINT fk_indice FOREIGN KEY(`Indice`) REFERENCES `ENSEIGNANT`(`Indice`)
);

CREATE TABLE IF NOT EXISTS `RESPONSABLE`(
    `numResponsable`INT(20) NOT NULL AUTO_INCREMENT,
    `Indice` INT(20) DEFAULT NULL,
    `nom` DEFAULT NULL,
    CONSTRAINT pk_numResponsable PRIMARY KEY(`numResponsable`),
    CONSTRAINT fk_Indice FOREIGN KEY(`Indice`) REFERENCES `ENSEIGNANT`(`Indice`),
);

CREATE TABLE IF NOT EXISTS `MATIERE`(
    `numMatiere` INT(20) NOT NULL AUTO_INCREMENT,
    `nomMatiere` VARCHAR(20) DEFAULT NULL,
    `numSalle` INT(20) DEFAULT NULL
    CONSTRAINT pk_numMatiere PRIMARY KEY(`numMatiere`),
    CONSTRAINT fk_numSalle FOREIGN KEY(`numSalle`) REFERENCES `SALLE`(`numSalle`)
);

CREATE TABLE IF NOT EXISTS `ETUDIANT`(
    `numEtudiant` INT(20) NOT NULL AUTO_INCREMENT,
    `nomEtudiant` VARCHAR(20) DEFAULT NULL,
    `prenomEtudiant` VARCHAR(20) DEFAULT NULL,
    `telEtudiant` VARCHAR(12) DEFAULT NULL,
    `mailEtudiant` VARCHAR(20) DEFAULT NULL,
    `anneeEntree` INT(4) DEFAULT NULL,
    `numBulletin`INT(20) DEFAULT NULL,
    `numFiche`INT(20) DEFAULT NULL,
    CONSTRAINT pk_numEtudiant PRIMARY KEY(`numEtudiant`),
    CONSTRAINT fk_numBulletin FOREIGN KEY(`numBulletin`) REFERENCES `BULLETIN`(`numBUlletin`),
    CONSTRAINT fk_numFiche FOREIGN KEY(`numFiche`) REFERENCES `FICHESIGNALETIQUE`(`numFiche`)
);

CREATE TABLE IF NOT EXISTS `BULLETIN`(
    `numBulletin` INT(20) NOT NULL AUTO_INCREMENT,
    `note` INT(20) DEFAULT NULL,
    `numEtudiant` INT(20) DEFAULT NULL,
    `numMatiere` INT(20) DEFAULT NULL,
    CONSTRAINT pk_numBulletin PRIMARY KEY(`numBulletin`),
    CONSTRAINT fk_numEtudiant FOREIGN KEY(`numEtudiant`) REFERENCES `ETUDIANT`(`numEtudiant`),
    CONSTRAINT fk_numMatiere FOREIGN KEY(`numMatiere`) REFERENCES `MATIERE`(`numMatiere`)
)