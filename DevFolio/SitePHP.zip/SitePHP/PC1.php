<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
<!--Section contenant les images du produits-->
    <div class="important">
        <div class="images">
            <img src="Photos/Megaport_High_End.png" alt="MegaPort"><br>
			<img src="Photos/PC/PC1/MegaPort2.png" alt="MegaPort">
			<img src="Photos/PC/PC1/MegaPort3.png" alt="MegaPort">
        </div>
		<!--Section contenant le nom, le prix et la description produit ainsi que un bouton pour acheter le produit-->
        <div class="description">
            <table class="tableau">
                <tr>
					<td><h1>Megaport High End PC Gamer</h1></td>
				</tr>
				<tr>
					<td><h2>3500€</h2></td>
				</tr>
				<tr>
					<td>Le processeur Intel Core i9 12900F avec 16 cœurs, 24 threads et une fréquence de boost allant jusqu'à 5,1 GHz, associé à 32 Go de RAM (3200 MHz) et à un SSD M.2 de 2 To, vous permet de profiter de tous les jeux et programmes avec une vitesse et une qualité optimales.
						Avec la NVIDIA RTX 3080 (10 Go GDDR6X VRAM), vous obtenez l'une des cartes graphiques les plus puissantes du marché. Grâce à des technologies modernes telles que le ray tracing et le DLSS, vous allez expérimenter vos jeux vidéo avec le meilleur affichage possible et des performances exceptionnelles, même en 4K.
						Vous recevrez ce système optimisé avec une licence originale de Windows 11 Home préinstallée directement. Il vous suffit donc de le déballer, de le brancher et de vous lancer dans l'aventure, notamment grâce à la carte Wifi intégrée.</td>
				</tr>
				<tr>
					<td><a href="Acheter.php"><button>Acheter</button></a></td>
				</tr>
            </table>
        </div>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>
<!--Mes Réseaux-->
		</div>
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>