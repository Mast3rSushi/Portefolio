<nav>
    <div class="navbar">
        <div class="link_nav">
            <a href="index.php"><img src="images/icon.png" alt="Logo_Barrage.com"></a>
            <a href="Histoire.php">Histoire</a>
            <a href="Fonctionnement.php">Fonctionnement</a>
            <a href="Types.php">Types de barages</a>
            <a href="Avan-Incon.php">Avantages / Inconvénient</a>
            <button onclick="window.location.href = 'Login.php';">Mon compte</button>
        </div>
    </div>
</nav>