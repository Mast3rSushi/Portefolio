<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
	
	<!--Sections contenant les produits, une petite description et le prix-->
    <h1>Jeux</h1>
    <div class="Produits">
        <img src="Photos/Jeux/Minecraft/Minecraft.png" alt="Minecraft">
        <a href="Minecraft.php">Minecraft</a><br>
        <p>Minecraft est un jeu qui consiste à placer des blocs et à partir dans des aventures.</p>
        <p class="Prix" style="margin: 50px; ;">50€</p>
    </div><br><br><br><br><br><br>

    <div class="Produits">
        <img src="Photos/Jeux/Lol/LOL.png" alt="LOL">
        <a href="Lol.php">League of Legends PS4</a><br>
        <p>League of Legends est un jeu en équipe avec plus de 140 champions, pour des actions à couper le souffle</p>
        <p class="Prix" style="margin: 50px; ;">20€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Jeux/R6.png" alt="R6">
        <a href="https://store.steampowered.com/app/359550/Tom_Clancys_Rainbow_Six_Siege/?l=french">Rainbow Six Siege</a><br>
        <p>Jeu de tir tactique réaliste qui se joue en équipe, où vous devrez allier talent et stratégie.</p>
        <p class="Prix" style="margin: 50px; ;">70€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Jeux/Battlefront.png" alt="Battlefront">
        <a href="https://www.ea.com/fr-fr/games/starwars/battlefront/star-wars-battlefront-2">Star Wars Battlefront 2</a><br>
        <p>Devenez le héros ultime des batailles Star Wars™ de vos rêves. Mettez votre maîtrise du blaster, du sabre laser et de la Force à l’épreuve dans de gigantesques batailles en ligne, des escarmouches hors lignes contre l'IA, ou en Coop aux côtés de vos amis.</p>
        <p class="Prix" style="margin: 50px; ;">100€</p>
    </div>
	<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="../Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>
    



        