<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
	<!--Section contenant une image interactive-->
	<div class="Recommandation">
		<h1>Nos Recommandations</h1>
		
		<img src="Photos/Pc-gamer.png" usemap="#image-map">

		<map name="image-map">
    		<area target="" alt="" title="" href="https://www.amazon.fr/upHere-Ventilateur-Dordinateur-Silencieux-Pack（NK12BK3-5）/dp/B08ZK6TBB2/ref=sr_1_10?keywords=ventilateur+pc&qid=1670884952&sr=8-10" coords="252,339,156,215" shape="rect">
    		<area target="" alt="" title="" href="https://www.amazon.fr/MAXSUN-GT-710-consommation-Ventilateur/dp/B08R8NZB3Y/ref=sr_1_1?c=ts&keywords=Cartes+graphiques&qid=1670884075&refinements=p_n_feature_seven_browse-bin%3A8323153031&s=computers&sr=1-1&ts_id=430340031" coords="460,425,211,390" shape="0">
   		 	<area target="" alt="" title="" href="https://www.amazon.fr/Processeur-Pentium-LGA1200-chipset-BX80701G6400/dp/B086MHSH2Z/ref=sr_1_2?keywords=Processeur+Intel+Pentium&qid=1670883641&sr=8-2" coords="272,245,347,344" shape="0">
    		<area target="" alt="" title="" href="https://www.amazon.fr/ordinateur-portable-Hys64d32020gdl-7-b-32-Mx64-SDRAM-Pc2100s-2033-0-a1/dp/B00B875XM4/ref=sr_1_6?c=ts&keywords=Mémoire+RAM&qid=1670884485&refinements=p_4%3AInfineon&s=computers&sr=1-6&ts_id=430351031" coords="392,220,417,363" shape="0">
    		<area target="" alt="" title="" href="https://www.amazon.fr/TACENS-ANIMA-AC5-Boîtier-Refroidissement/dp/B09V2RVFBJ/ref=asc_df_B09V2RVFBJ/?tag=googshopfr-21&linkCode=df0&hvadid=553510437310&hvpos=&hvnetw=g&hvrand=5280691917729430445&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1006094&hvtargid=pla-1650160892833&psc=1" coords="522,20,673,737" shape="0">
    		<area target="" alt="" title="" href="https://www.laboutiquedunet.com/p-SAM06591/x.html?cc1=10042" coords="122,518,491,705" shape="0">
    		<area target="" alt="" title="" href="https://www.topachat.com/pages/detail2_cat_est_micro_puis_rubrique_est_w_raps_puis_ref_est_in20003117.html" coords="272,454,476,513" shape="0">
		</map>
	</div><br>
	
	<!--Sections contenant les produits, une petite description et le prix-->
    <h1>PC</h1>
    <div class="Produits">
        <img src="Photos/Megaport_High_End.png" alt="MegaPort">
        <a href="PC1.php">Megaport High End PC Gamer</a><br>
        <p>Intel Core i9-12900F 16-Coeurs jusqu'à 5,10GHz Turbo • Windows 11 • GeForce RTX3080 • 32Go • 2To M.2 SSD • Refroidissement Liquide • Unité Centrale Ordinateur de Bureau</p>
        <p class="Prix" style="margin: 50px; ;">3500€</p>
    </div><br><br><br><br><br><br>

    <div class="Produits">
        <img src="Photos/PC/BEASTCOMQ5.png" alt="BEASTCOM">
        <a href="https://www.amazon.fr/BEASTCOM-Gaming-Gamer-NVIDIA-Windows/dp/B09V1LHQ9C/ref=sr_1_13?crid=1OC19Q8K27RWM&keywords=pc+gamer&qid=1670878007&sprefix=pc+%2Caps%2C143&sr=8-13">BEASTCOM Q5</a><br>
        <p>AMD Ryzen 5 5500 6X 4,20 GHz 12 Threads | NVIDIA RTX 3060 8Go | 16Go RAM | 1To NVMe SSD | HDMI | USB 3.2 | WiFi | Windows 11 Pro</p>
        <p class="Prix" style="margin: 50px; ;">1500€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/PC/Asus/ASUSTUFA15-TUF507RR-HN076W.png" alt="Asus">
        <a href="AsusPortable.php">ASUS TUF A15-TUF507RR-HN076W</a><br>
        <p>Ordinateur Portable Gaming 15" FHD 144Hz (AMD Ryzen 7-6800H, 16G (2x8 Go) RAM, 512Go PCIe SSD, GeForce RTX 3070) Windows 11 Clavier Rétroéclairé AZERTY Français RGB 1 Zone</p>
        <p class="Prix" style="margin: 50px; ;">2000€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/PC/HP/HPPavilionGaming 17.png" alt="HP">
        <a href="HP.php">HP Pavilion Gaming 17</a><br>
        <p>Portable Gaming 17.3" FHD IPS (Intel Core i5-11300H, RAM 16 Go, SSD 512 Go, NVIDIA GeForce GTX 1650, AZERTY, Windows 11 Famille)</p>
        <p class="Prix" style="margin: 50px; ;">2000€</p>
    </div>
	<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>
    



        