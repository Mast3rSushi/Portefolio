<!DOCTYPE html>
<head>
	<!-- Titre et lien vers le CSS -->
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
		
	</div>
	<!--Sections contenant les produits, une petite description et le prix-->
	<h1>Divers</h1>

	<div class="Produits">
        <img src="Photos/Divers/Plaine.png" alt="Plaine">
        <a href="Air.php">Air Ambiant</a><br>
        <p>Air bio qui permet de respirer pour vivre</p>
        <p class="Prix" style="margin: 50px; ;">8000€</p>
    </div><br><br><br><br><br><br>

    <div class="Produits">
        <img src="Photos/Divers/Balaie.png" alt="Balaie">
        <a href="https://www.amazon.fr/balai-coco-grande-dimension-cantonnier/dp/B07S79KZ7Z/ref=asc_df_B07S79KZ7Z/?tag=googshopfr-21&linkCode=df0&hvadid=354007743032&hvpos=&hvnetw=g&hvrand=2345065066141403266&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1006094&hvtargid=pla-771458473576&psc=1&tag=&ref=&adgrpid=72898046538&hvpone=&hvptwo=&hvadid=354007743032&hvpos=&hvnetw=g&hvrand=2345065066141403266&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1006094&hvtargid=pla-771458473576">Balai coco grande dimension</a><br>
        <p>60, 80 ou 100 cm avec manche cantonnier 1.40m (80)</p>
        <p class="Prix" style="margin: 50px; ;">99€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Divers/Microsoft.png" alt="Microsoft">
        <a href="Microsoft.php">Microsoft</a><br>
        <p>Microsoft Corporation est une multinationale informatique et micro-informatique américaine</p>
        <p class="Prix" style="margin: 50px; ;">Prix Indéterminé</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Divers/Cuisine.png" alt="Cuisine">
        <a href="https://www.roseoubleu.fr/janod-cuisine-enfant-macaron-maxi-bois-a212664.html?a=b&pred=FRRPA%2CFRRPB%2CFRRPC%2CFRRPD%2CFRRPE%2CFRRPWEA%2CFRRPWEB%2CFRRP001%2C&c=p_aw%2Cp2aw%2Cp3aw%2Cp4aw%2Cp5aw%2Cprwea%2Cprweb%2Cp_akt_pla2%2C&rp=&os=&fdcampaign=feed/fr/14443/googleshoppingint/A212664&adword=Google/PLA_AW_Spielzeug_d_t&RefID=PLA_FR0000_PLA_AW_Spielzeug_d_t&gclid=Cj0KCQiA4uCcBhDdARIsAH5jyUlSOxV9KpsXCLu3zq9heJIdfNDIZzXE3myYNuv9kD93PBz0i2njDfEaAh7PEALw_wcB">Janod Cuisine Macaron Maxi bois</a><br>
        <p>Pièce où l'on prépare et fait cuire les aliments.</p>
        <p class="Prix" style="margin: 50px; ;">10 000€</p>
    </div>
<!--Contact-->
	<div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="Photos/Instagram.png" alt="Instagram Logo"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="Photos/twitch.png" alt="Twitch Logo"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube Logo"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>