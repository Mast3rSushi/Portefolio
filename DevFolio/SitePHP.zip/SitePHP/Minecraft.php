<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
<!--Section contenant les images du produits-->
    <div class="important">
        <div class="images">
            <img src="Photos/Jeux/Minecraft/Minecraft.png" alt="Mine"><br>
			<img src="Photos/Jeux/Minecraft/Mine1.png" alt="Mine">
			<img src="Photos/Jeux/Minecraft/Mine2.png" alt="Mine">
            <img src="Photos/Jeux/Minecraft/Mine3.png" alt="Mine">
            <img src="Photos/Jeux/Minecraft/Mine4.png" alt="Mine">
            <img src="Photos/Jeux/Minecraft/Mine5.png" alt="Mine">
            
        </div>
		<!--Section contenant le nom, le prix et la description produit ainsi que un bouton pour acheter le produit-->
        <div class="description">
            <table class="tableau">
                <tr>
					<td><h1>Minecraft</h1></td>
				</tr>
				<tr>
					<td><h2>50€</h2></td>
				</tr>
				<tr>
					<td>FAIS PREUVE D’INGÉNIOSITÉ <br>
                        Fabrique et utilise le décor qui t’entoure pour réunir des matériaux de construction. Découvre comment tu peux réaliser de nouvelles créations en abattant des arbres. <br> <br>
                        SURVIS À LA NUIT <br>
                        Ne laisse pas de place à l’imprévu en gardant tes distance avec les créatures errantes : nul ne sait ce qui pourrait arriver si tu t’approchais de trop ! <br> <br>
                        RÉALISE DES CONSTRUCTIONS EXTRAORDINAIRES <br>
                        Découvre les différentes manières d’utiliser la poudre de minerai de redstone pour améliorer tes créations, leur donner vie ou les rendre explosives.
                    </td>
				</tr>
				<tr>
					<td><a href="Acheter.php"><button>Acheter</button></a></td>
				</tr>
            </table>
        </div>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>