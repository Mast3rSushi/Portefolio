<!DOCTYPE html>
<head>
	<!-- Titre et lien vers le CSS -->
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
	<div id="timer">
		<script src="timer.js"> </script>

	<!--Section contenant une description de l'entreprise-->	
	</div>
	<div class="Fenetre">
	<div class="Profil">
		<div class="Propos">
			<h1>Qui Sommes nous</h1>
			<h2>Ce site est une parodie donc si il y a des "erreurs" ou des incohérences, c'est volontaire.</h2>
			<p>Shopping Drop est un site de Drop Shipping qui vous arnaque. Nous sommes une équipe de 1 personne et nous travaillons 1 fois tout les siècles pour vous proposez un site performant car on adore nos clients (surtout votre argent). Nous sommes situé sur Paris et nos fournisseurs sont principalement Aliexpress mais vous ne le savez pas car si vous avez acheté, vous vous êtes fait arnaqué.</p>
		</div>
		<!--Section contenant l'emplacement de l'entreprise-->
		<div class="Carte">
			<img src="Photos/Carte.png" alt="Carte">
		</div>
		</div>
	</div>
	<!--Section contenant un tableau de l'équipe du site-->
	<div class="Membre">
		<h1>L'équipe</h1>
		<table>
			<tr>
				<td><h2>Membre</h2></td>
				<td><h2>Fondateur</h2></td>
				<td><h2>Développeur</h2></td>
				<td><h2>Community Manager</h2></td>
				<td><h2>Service Client</h2></td>
			</tr>
			<tr>
				
				<td><p>Romain</p></td>
				<td><p>O</p></td>
				<td><p>O</p></td>
				<td><p>O</p></td>
				<td><p>O</p></td>
			</tr>
		</table>
	</div>
	<!--Section contenant les réseaux de l'entreprise-->
	<h1>Nos Réseaux</h1>
	<div class="Social">
		
		<a href="https://www.instagram.com/romain_ki/"><img src="Photos/Instagram.png" alt="Instagram Logo"></a>
		<a href="https://www.twitch.tv/mast3rsushi"><img src="Photos/twitch.png" alt="Twitch Logo"></a>
		<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube Logo"></a>
		<p>Discord : Mast3rSushi#0023</p>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>