<?php
// Récupération des informations de la requête
$date = date('M j H:i:s');
$path = $_SERVER['REQUEST_URI'];
$error = '';
$user = '';
if (isset($_SESSION['username'])) {
    $user = $_SESSION['username'];
}
$browser = $_SERVER['HTTP_USER_AGENT'];
$connect_time = '';
if (isset($_SESSION['connect_time'])) {
    $connect_time = $_SESSION['connect_time'];
}
$ip = $_SERVER['REMOTE_ADDR'];

// Formatage des informations pour l'enregistrement dans le fichier de log
$log_line = "$date - local1 - path:\"$path\" error:\"$error\" user:$user ($browser) connect:$connect_time IP:$ip\n";

// Enregistrement dans le fichier de log
$log_file = 'logs/access.txt';
$handle = fopen($log_file, 'a');
fwrite($handle, $log_line);
fclose($handle);
?>