<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
<!--Section contenant les images du produits-->
    <div class="important">
        <div class="images">
            <img src="Photos/PC/HP/HPPavilionGaming 17.png" alt="HP"><br>
			<img src="Photos/PC/HP/HP1.png" alt="HP">
			<img src="Photos/PC/HP/HP2.png" alt="HP">
            <img src="Photos/PC/HP/HP3.png" alt="HP">
            <img src="Photos/PC/HP/HP4.png" alt="HP">
            <img src="Photos/PC/HP/HP5.png" alt="HP">
            <img src="Photos/PC/HP/HP6.png" alt="HP">
        </div>
		<!--Section contenant le nom, le prix et la description produit ainsi que un bouton pour acheter le produit-->
        <div class="description">
            <table class="tableau">
                <tr>
					<td><h1>HP Pavilion Gaming 17</h1></td>
				</tr>
				<tr>
					<td><h2>2000€</h2></td>
				</tr>
				<tr>
					<td>Windows 11 Famille <br>
                        PERFORMANCES FLUIDES : PC portable gaming avec processeur Intel Core i5-11300H, carte graphique NVIDIA GeForce GTX 1650 et 16 Go de RAM <br>
                        SUPERBE ÉCRAN : Écran Full HD IPS de 17,3 pouces (1920 x 1080), 144 Hz, anti-reflet, 250 nits, 45 % NTSC <br>
                        STOCKAGE : SSD 512 Go <br>
                        SYSTÈME DE REFROIDISSEMENT AMÉLIORÉ : Double système de ventilation - grandes grilles d’aération situées dans les coins arrière et entrées d’air supplémentaires <br>
                        AUTONOMIE : Jusqu'à 8h + Charge rapide (environ 50% de batterie en 45 minutes) <br>
                        SON HAUTE-QUALITÉ : Doubles haut-parleurs, HP Audio Boost et optimisation sonore signée Bang & Olufsen <br>
                        CONNECTIVITÉ : 1 port SuperSpeed USB type-C + 1 port SuperSpeed USB type-A + 1 port USB 2.0 type-A (veille et charge HP) + 1 port HDMI 2.0 + 1 port RJ-45 + 1 adaptateur secteur Smart Pin + 1 prise combinée casque/microphone + 1 lecteur de cartes multimédias SD multiformat
                        1 an de garantie</td>
				</tr>
				<tr>
					<td><a href="Acheter.php"><button>Acheter</button></a></td>
				</tr>
            </table>
        </div>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>
<!--Mes Réseaux-->
		</div>
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../../Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../../Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="../../Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>