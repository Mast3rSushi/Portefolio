<!DOCTYPE html>
<head>
	<!-- Titre et lien vers le CSS -->
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>	
	</div>
	<!--Section contenant les liens vers les autres pages-->
	<h1>Multimedia</h1>
	<div class="Theme">
		<a href="PC.php"><button>PC</button></a>
		<a href="Accessoire.php"><button>Accessoires</button></a>
		<a href="Jeux.php"><button>Jeux</button></a>
	</div>
<!--Contact-->
	<div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="Photos/Instagram.png" alt="Instagram Logo"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="Photos/twitch.png" alt="Twitch logo"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube Logo"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>