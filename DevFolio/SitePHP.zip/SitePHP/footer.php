<footer>
	<p>Copyright &copy; Kiekens Romain 2022-Date indéfini - All Right (peut être reserved)</p>
</footer>	