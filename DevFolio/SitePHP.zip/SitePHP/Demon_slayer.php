<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
<!--Section contenant les images du produits-->
    <div class="important">
        <div class="images">
            <img src="Photos/Mangas/Demon_slayer.png" alt=""><br>
			<img src="Photos/Mangas/Demon1.png" alt="">
			<img src="Photos/Mangas/demon2.png" alt="">
            <img src="Photos/Mangas/Demon3.png" alt="">
            <img src="Photos/Mangas/Demon4.png" alt="">
        </div>
		<!--Section contenant le nom, le prix et la description produit ainsi que un bouton pour acheter le produit-->
        <div class="description">
            <table class="tableau">
                <tr>
					<td><h1>Demon Slayer Collection Complète</h1></td>
				</tr>
				<tr>
					<td><h2>300€</h2></td>
				</tr>
				<tr>
					<td>Le Japon, au début du XXe siecle.
                        Un petit marchand de charbon nommé Tanjiro vit une vie sans histoire dans les montagnes. Jusqu’au jour tragique où, après une courte absence, il retrouve son village et sa famille massacrés par un ogre ! La seule survivante de cette tragédie est sa jeune sœur Nezuko. Hélas, au contact de la bête, celle-ci s’est à son tour métamorphosée en monstre...
                        Afin de renverser le processus et de venger sa famille, Tanjiro décide de partir en quête de vérité. Pour le jeune héros et sa sœur, c’est une longue aventure de sang et d’acier qui commence !</td>
				</tr>
				<tr>
					<td><a href="Acheter.php"><button>Acheter</button></a></td>
				</tr>
            </table>
        </div>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../../Photos/Instagram.png"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../../Photos/twitch.png"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="../../Photos/YouTube.png"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>