
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>ShoppingDrop</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>

<body>
	<?php include("header.php")?>
    <?php include("nav.php")?>
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
    <h1>Page de connexion</h1>
    <button onclick="window.location.href = 'logout.php';">Logout</button>
</body>
<?php include("footer.php")?>

</html>