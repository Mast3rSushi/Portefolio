<?php
session_start();

if (isset($_SESSION['username'])) {
    header('Location: compte.php');
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>ShoppingDrop</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>

<body>
	<?php include("header.php")?>
    <?php include("nav.php")?>
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
    <h1>Se Connecter</h1>
    <?php if (isset($_SESSION['error'])): ?>
        <p style="color:red">
            <?= $_SESSION['error'] ?>
        </p>
    <?php endif ?>
    <form method="post" action="login.php">
        <label>Utilisateur:</label>
        <input type="text" name="username"><br><br>
        <label>Mot de passe:</label>
        <input type="password" name="password"><br><br>
        <input type="submit" value="Se connecter">
    </form>
    <br>
    <p>Pas encore de compte? <a href="Inscrire.php">Créer un compte</a></p>
</body>
<?php include("footer.php")?>

</html>

<?php
unset($_SESSION['error']);
?>