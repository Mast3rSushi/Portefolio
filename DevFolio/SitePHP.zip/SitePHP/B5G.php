<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
<!--Section contenant les images du produits-->
    <div class="important">
        <div class="images">
            <img src="Photos/Mangas/BG5.png" alt=""><br>
			<img src="Photos/Mangas/bg1.png" alt="">
			<img src="Photos/Mangas/bg2.png" alt="">
            <img src="Photos/Mangas/bg3.png" alt="">
        </div>
		<!--Section contenant le nom, le prix et la description produit ainsi que un bouton pour acheter le produit-->
        <div class="description">
            <table class="tableau">
                <tr>
					<td><h1>Battle Games Collection Complète</h1></td>
				</tr>
				<tr>
					<td><h2>500€</h2></td>
				</tr>
				<tr>
					<td>Akira est un lycéen passionné de jeux vidéo tombé dans les griffes d'une mystérieuse organisation. Ses compagnons d'infortune et lui sont désormais les participants d’un jeu d’un genre nouveau. Radiés des registres de la population,
                        les voilà devenus des sujets d’expérimentations et ils vont se découvrir, chacun leur tour, des pouvoirs dévastateurs.
                        La décision d'Akira est prise : il va utiliser ces nouvelles facultés pour détruire l'organisation qui les retient captifs.Ses armes : un pouvoir que personne n’attend et un sens de la stratégie hors du commun.
                        Mais attention, pour tous les participants, le danger peut survenir à tout moment… Préparez-vous ! Combat dans 5, 4, 3...</td>
				</tr>
				<tr>
					<td><a href="Acheter.php"><button>Acheter</button></a></td>
				</tr>
            </table>
        </div>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>
		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../../Photos/Instagram.png"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../../Photos/twitch.png"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="../../Photos/YouTube.png"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>