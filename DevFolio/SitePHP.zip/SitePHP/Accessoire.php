<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
    <meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
    <?php include("header.php")?>
    <?php include("nav.php")?>
    <!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
	
    <!--Sections contenant les produits, une petite description et le prix-->
    <h1>Accessoires</h1>
    <div class="Produits">
        <img src="Photos/Accessoire/MSIMPGZ590Gaming Plus.png" alt="MSI">
        <a href="https://www.amazon.fr/MSI-Z590-Gaming-Carte-Intel/dp/B08WQ6VJ9S/ref=sr_1_5?adgrpid=69898982815&gclid=CjwKCAiAv9ucBhBXEiwA6N8nYONgeeMekRt580Mzx2hCelVKYtHZW-STzN5mSDqgdYUscuF4A7fWLBoCeBgQAvD_BwE&hvadid=601526395345&hvdev=c&hvlocphy=1006094&hvnetw=g&hvqmt=e&hvrand=8033593543562438385&hvtargid=kwd-852664222050&hydadcr=7967_2270242&keywords=carte-mère+pc+gamer&qid=1670882984&sr=8-5">MSI MPG Z590 Gaming Plus</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">250€</p>
    </div><br><br><br><br><br><br>

    <div class="Produits">
        <img src="Photos/Accessoire/RaspberryPi3Model B+.png" alt="Raspberry">
        <a href="https://www.topachat.com/pages/detail2_cat_est_micro_puis_rubrique_est_w_raps_puis_ref_est_in20003117.html">Raspberry Pi 3 Model B+</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">100€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/ProcesseurAMDRyzen95900XSocketAM4.png" alt="AMD">
        <a href="https://www.amazon.fr/AMD-Ryzen-9-5900X-RyzenTM/dp/B08164VTWH/ref=sr_1_5?c=ts&keywords=Processeurs&qid=1670883458&s=computers&sr=1-5&ts_id=430352031">Processeur AMD Ryzen 9 5900X Socket AM4</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">500€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/ProcesseurIntelPentiumGoldG-6400.png" alt="Pentium">
        <a href="https://www.amazon.fr/Processeur-Pentium-LGA1200-chipset-BX80701G6400/dp/B086MHSH2Z/ref=sr_1_2?keywords=Processeur+Intel+Pentium&qid=1670883641&sr=8-2">Processeur Intel® Pentium Gold G-6400</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">150€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/ASUSTUFGAMINGNVIDIAGeForceRTX4090OCEdition.png" alt="GeForce">
        <a href="https://www.amazon.fr/ASUS-GAMING-NVIDIA-GeForce-4090/dp/B0BHD9TS9Q/ref=asc_df_B0BHD9TS9Q/?tag=googshopfr-21&linkCode=df0&hvadid=603516700034&hvpos=&hvnetw=g&hvrand=3207391138167931951&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1006094&hvtargid=pla-1875345679406&psc=1">ASUS TUF GAMING NVIDIA GeForce RTX 4090 OC Edition</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">3000€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/MAXSUNCarteGraphiqueExterneGeForceGT710.png" alt="GeForce">
        <a href="https://www.amazon.fr/MAXSUN-GT-710-consommation-Ventilateur/dp/B08R8NZB3Y/ref=sr_1_1?c=ts&keywords=Cartes+graphiques&qid=1670884075&refinements=p_n_feature_seven_browse-bin%3A8323153031&s=computers&sr=1-1&ts_id=430340031">MAXSUN Carte Graphique Externe GeForce GT710</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">150€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/KingstonFuryRenegade.png" alt="Kingston">
        <a href="https://www.amazon.fr/Kingston-Renegade-6400MT-Mémoire-Gamer/dp/B0B72BM63Q/ref=sr_1_1?c=ts&keywords=Mémoire+RAM&qid=1670884326&refinements=p_36%3A428411031&rnid=428393031&s=computers&sr=1-1&ts_id=430351031">Kingston Fury Renegade</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">450€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/Mémoirepourordinateurportable.png" alt="RAM">
        <a href="https://www.amazon.fr/ordinateur-portable-Hys64d32020gdl-7-b-32-Mx64-SDRAM-Pc2100s-2033-0-a1/dp/B00B875XM4/ref=sr_1_6?c=ts&keywords=Mémoire+RAM&qid=1670884485&refinements=p_4%3AInfineon&s=computers&sr=1-6&ts_id=430351031">Mémoire pour ordinateur portable</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">100€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/EZDIY-FABMoonlight.png" alt="EZDIY-FAB">
        <a href="https://www.amazon.fr/EZDIY-FAB-Moonlight-Ventilateur-Télécommande-Adressable/dp/B07XF4ZPWL/ref=sr_1_12?keywords=pc+gamer&qid=1670884772&s=computers&sr=1-12">EZDIY-FAB Moonlight</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">200€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/upHereVentilateurPC.png" alt="upHere">
        <a href="https://www.amazon.fr/upHere-Ventilateur-Dordinateur-Silencieux-Pack（NK12BK3-5）/dp/B08ZK6TBB2/ref=sr_1_10?keywords=ventilateur+pc&qid=1670884952&sr=8-10">upHere Ventilateur PC</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">80€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/SuperFlowerLeadexPlatinum8PackEdition.png" alt="Super">
        <a href="https://www.digitec.ch/fr/s1/product/super-flower-leadex-platinum-8pack-edition-2000-w-alimentation-pc-5338712">Super Flower Leadex Platinum 8Pack Edition</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">700€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/SAMSUNGAdaptateursecteurUSB-C.png" alt="SAMSUNG">
        <a href="https://www.laboutiquedunet.com/p-SAM06591/x.html?cc1=10042">SAMSUNG Adaptateur secteur USB-C</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">50€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/TALIUSChronos.png" alt="TALIUS">
        <a href="https://www.amazon.fr/TALIUS-Cronos-Verre-trempé-Boîte/dp/B07NVT6NQV/ref=sr_1_7_mod_primary_new?adgrpid=58759797320&gclid=CjwKCAiAv9ucBhBXEiwA6N8nYAFsingc1NcObC5voRrwlgcH0Jr166eC4xg9_K3g50L1TuOGvo3QVhoC0j0QAvD_BwE&hvadid=601472819694&hvdev=c&hvlocphy=1006094&hvnetw=g&hvqmt=e&hvrand=2049447262788676706&hvtargid=kwd-299152725286&hydadcr=7970_2270199&keywords=boitier+pc+gamer&qid=1670885307&sbo=RZvfv%2F%2FHxDF%2BO5021pAnSA%3D%3D&sr=8-7">TALIUS Chronos</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">250€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Accessoire/TACENSANIMAAC5.png" alt="TACENS">
        <a href="https://www.amazon.fr/TACENS-ANIMA-AC5-Boîtier-Refroidissement/dp/B09V2RVFBJ/ref=asc_df_B09V2RVFBJ/?tag=googshopfr-21&linkCode=df0&hvadid=553510437310&hvpos=&hvnetw=g&hvrand=5280691917729430445&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1006094&hvtargid=pla-1650160892833&psc=1">TACENS ANIMA AC5</a><br>
        <p></p>
        <p class="Prix" style="margin: 50px; ;">80€</p>
    </div>


<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
        <!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="../Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
    <!--footer contenant le copyright-->
    <?php include("footer.php")?>
</body>
</html>
    



        