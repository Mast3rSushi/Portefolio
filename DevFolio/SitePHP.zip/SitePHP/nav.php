<nav>
			<ul>
				<li class="deroulant"><img src="Photos/Logo.png" alt="Logo"></li>
			  <li class="deroulant"><a href="index.php">Shopping Drop &ensp;</a></li>
			  <li class="deroulant"><a href="">Produits &ensp;</a>
				<ul class="sous">
				  <li><a href="Multimedia.php">Multimedia</a></li>
				  <li><a href="Manga.php">Manga</a></li>
				  <li><a href="Divers.php">Divers</a></li>
				</ul>
			  </li>
			  <li><a href="Connexion.php">Se Connecter</a></li>
			  <li><a href="A_Propos.php">A propos</a></li>
			</ul>
</nav>

<?php include("loger.php")?>