<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
	
<!--Sections contenant les produits, une petite description et le prix-->
    <h1>Mangas</h1>
    <div class="Produits">
        <img src="Photos/Mangas/Demon_slayer.png" alt="Demon">
        <a href="Demon_slayer.php">Demon Slayer Collection Complète</a><br>
        <p>Demon slayer, connue au Japon sous le nom Kimetsu no yaiba est une série de manga écrite et dessinée par Koyoharu Gotōge.</p>
        <p class="Prix" style="margin: 50px; ;">300€</p>
    </div><br><br><br><br><br><br>

    <div class="Produits">
        <img src="Photos/Mangas/BG5.png" alt="BG5">
        <a href="B5G.php">Battle Games in 5 Secondes</a><br>
        <p>attle Game in 5 Seconds également connu sous le nom de Battle in 5 Seconds After Meeting est une série de mangas japonais, écrite par Saizō Harawata et illustrée par Kashiwa Miyako.</p>
        <p class="Prix" style="margin: 50px; ;">500€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Mangas/DG.png" alt="Darwin">
        <a href="https://livre.fnac.com/a9313657/Darwin-s-Game-Tome-08-Darwin-s-Game-Flipflop-s">Darwin's Game</a><br>
        <p>Un thriller social décapant sur fond de bataille urbaine 2.0</p>
        <p class="Prix" style="margin: 50px; ;">10€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Mangas/EMD.png" alt="EMD">
        <a href="https://livre.fnac.com/a16581199/Excuse-me-dentist-it-s-touching-me-Tome-01-Excuse-me-dentist-it-s-touching-me-Sho-Yamazaki">Excuse Me Dentist, It's Touching Me !</a><br>
        <p>Deux clans de yakuzas se partagent la ville depuis des générations : le Kokuyo-kai et ses hommes en noir et les Shinju, généralement vêtus de blanc.</p>
        <p class="Prix" style="margin: 50px; ;">67€</p>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>
<!--Mes Réseaux-->
		</div>
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>
    



        