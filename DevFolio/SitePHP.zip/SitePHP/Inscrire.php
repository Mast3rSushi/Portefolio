<?php

$filename = "files/users.txt";
$file = fopen($filename, "a");
fclose($file);


// Définition des variables pour les erreurs
$nameErr = $emailErr = $passwordErr = "";
// Définition des variables pour stocker les données saisies par l'utilisateur
$name = $email = $password = "";
$confirmPasswordErr = "";



// Vérification si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["name"])) {
        $nameErr = "Le nom est obligatoire";
    } else {
        $name = test_input($_POST["name"]);
        // Vérification si le nom ne contient que des lettres et des espaces
        if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            $nameErr = "Seuls les lettres et les espaces sont autorisés";
        }
    }

    // Vérification du champ email
    if (empty($_POST["email"])) {
        $emailErr = "L'adresse email est obligatoire";
    } else {
        $email = test_input($_POST["email"]);
        // Vérification si l'adresse email est valide
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "L'adresse email n'est pas valide";
        }
    }

    // Vérification du champ mot de passe
    if (empty($_POST["password"])) {
        $passwordErr = "Le mot de passe est obligatoire";
    } else {
        $password = test_input($_POST["password"]);
        // Vérification si le mot de passe est valide
        if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$/", $password)) {
            $passwordErr = "Le mot de passe doit contenir au moins 12 caractères, une lettre majuscule, une lettre minuscule, un chiffre et un caractère spécial (@$!%*?&)";
        }
    }

    // Si toutes les validations ont réussi, stockage des données dans un fichier texte brut
    if (empty($nameErr) && empty($emailErr) && empty($passwordErr)) {
        $filename = "files/users.txt";
        $file = fopen($filename, "a");
        fwrite($file, "$name;$email;$password\n");
        fclose($file);
        header("Location: index.php");
    }
}

// Fonction de nettoyage des données saisies par l'utilisateur
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>ShoppingDrop</title>
    <link rel="stylesheet" type="text/css" href="Style.css">
</head>

<body>
    <?php include("header.php")?>
    <?php include("nav.php")?>
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
    
    <h2>Inscription</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Utilisateur:</label>
        <input type="text" id="name" name="name" value="<?php echo $name; ?>">
        <span class="error">
            <?php echo $nameErr; ?>
        </span>
        <br><br>
        <label for="email">Adresse email:</label>
        <input type="email" id="email" name="email" value="<?php echo $email; ?>">
        <span class="error">
            <?php echo $emailErr; ?>
        </span>
        <br><br>
        <label for="password">Mot de passe:</label>
        <input type="password" id="password" name="password">
        <span class="error">
            <?php echo $passwordErr; ?>
        </span>
        <br><br>
        <label for="confirm_password">Confirmation du mot de passe:</label>
        <input type="password" id="confirm_password" name="confirm_password">
        <span class="error">
            <?php echo $confirmPasswordErr; ?>
        </span>
        <br><br>
        <input type="submit" name="submit" value="S'inscrire">
    </form>

    <p>Déjà inscrit ? <a href="Connexion.php">Connectez-vous ici</a>.</p>
</body>
    <?php include("footer.php")?>
</html>
<?php
// Enregistrement des données dans un fichier texte
if (isset($_POST["submit"]) && empty($nameErr) && empty($emailErr) && empty($passwordErr) && empty($confirmPasswordErr)) {
    // Ouverture du fichier pour enregistrement
    $fileName = "files/users.txt";
    $file = fopen($fileName, "a");
    if ($file === false) {
        die("Erreur d'ouverture du fichier.");
    }

    // Écriture des données dans le fichier
    $data = $name . ":" . password_hash($password, PASSWORD_DEFAULT) . ":" . $email . "\n";
    fwrite($file, $data);

    // Fermeture du fichier
    fclose($file);

    // Redirection vers la page de connexion
    header("Location: login.php");
    exit();
}
?>