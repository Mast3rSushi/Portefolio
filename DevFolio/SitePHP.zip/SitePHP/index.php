<!DOCTYPE html>
<head>
	<!-- Titre et lien vers le CSS -->
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<!-- Barre de Navigation -->
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
	<div id="timer">
		<script src="timer.js"> </script>
		
	</div>

	<!--Div contenant les conditions de vente-->
	<div class="Principale">
		<div class="gauche">
			<img src="Photos/Livraison.gif" alt="Livraison">
			<p>Colis protégé au minimum car on adore se faire de l'argent</p>
		</div>
		<div class="milieu">
			<img src="Photos/34fois.gif" alt="34fois">
			<p>Paiement en 3 ou 4 fois avec intêret uniquement</p>
		</div>
		<div class="droite">
			<img src="Photos/Camion.gif" alt="Camion">
			<p>Vos colis font 30 fois le tour de la planète avant d'arriver chez vous car on adore le gazoil</p>
		</div>
	</div>

	<!--Le Caroussel ou Slider-->
	<h1>Notre Sélection</h1>
	<div class="slider-container">
		<div class="menu">
			<label for="slide-dot-1"></label>
			<label for="slide-dot-2"></label>
			<label for="slide-dot-3"></label>
			<label for="slide-dot-4"></label>
		</div>
		<input class="slide-input" id="slide-dot-1" type="radio" name="slides" checked >
		<img class="slide-img" src="Photos/Megaport_High_End.png" alt="MegaPort">

		<input class="slide-input" id="slide-dot-2" type="radio" name="slides">
		<img class="slide-img" src="Photos/Divers/air3.png" alt="air3">
	
		<input class="slide-input" id="slide-dot-3" type="radio" name="slides">
		<img class="slide-img" src="Photos/Mangas/BG5.png" alt="BG5">
	
		<input class="slide-input" id="slide-dot-4" type="radio" name="slides">
		<img class="slide-img" src="Photos/Figurines/Itsuki.png" alt="Itsuki">
	</div>
	<!--Bouttons pour acheter les objets dans le slider-->
	<div class="btn-toolbar">
		<a href="PC1.php"><button type="button" id="btnSubmit" class="btn btn-primary btn-sm">En Savoir Plus</button></a>
		<a href="Air.php"><button type="button" id="btnCancel" class="btn btn-primary btn-sm">En Savoir Plus</button></a>
		<a href="B5G.php"><button type="button" id="btnCancel" class="btn btn-primary btn-sm">En Savoir Plus</button></a>
		<a href="Itsuki.php"><button type="button" id="btnCancel" class="btn btn-primary btn-sm">En Savoir Plus</button></a>
	  </div>
	  <!--Contact-->
	<div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>
			
		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h2>Rejoingnez-nous</h2>
			<a href="https://www.instagram.com/romain_ki/"><img src="Photos/Instagram.png" alt="Instagram Logo"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="Photos/twitch.png" alt="Twitch Logo"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="Photos/YouTube.png" alt="Youtube Logo"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>