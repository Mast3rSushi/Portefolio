<header>
	<p>Ceci est le header</p>
</header>