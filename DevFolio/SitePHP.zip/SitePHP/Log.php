<?php
session_start();

$username = $_POST['username'];
$password = $_POST['password'];

if (empty($username) || empty($password)) {
    $_SESSION['error'] = "Nom d'utilisateur et mot de passe sont obligatoires.";
    header('Location: Login.php');
    exit();
}

if (preg_match('/[^a-zA-Z0-9&é~#{(\[\)\]\|_\^à@\)\=}]/', $username)) {
    $_SESSION['error'] = "Nom d'utilisateur invalide.";
    header('Location: Login.php');
    exit();
}

if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$/', $password)) {
    $_SESSION['error'] = "Mot de passe invalide.";
    header('Location: Login.php');
    exit();
}

$file = 'files/users.txt';
$found = false;
$lines = file($file, FILE_IGNORE_NEW_LINES);
foreach ($lines as $line) {
    $data = explode(':', $line);
    if ($data[0] == $username && password_verify($password, $data[1])) {
        $found = true;
        break;
    }
}

if (!$found) {
    $_SESSION['error'] = "Nom d'utilisateur ou mot de passe incorrect.";
    header('Location: Login.php');
    exit();
}

$_SESSION['username'] = $username;
header('Location: Compte.php');
exit();
?>