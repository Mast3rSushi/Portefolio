<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
	
<!--Sections contenant les produits, une petite description et le prix-->
    <h1>Figurines</h1>
    <div class="Produits">
        <img src="Photos/Figurines/Itsuki.png" alt="Itsuki">
        <a href="Itsuki.php">THE QUINTESSENTIAL QUINTUPLETS - FIGURINE ITSUKI NAKANO - ICHIBAN KUJI BLESSED GATEWAY</a><br>
        
        <p class="Prix" style="margin: 50px; ;">200€</p>
    </div><br><br><br><br><br><br>

    <div class="Produits">
        <img src="Photos/Figurines/Miko.png" alt="Miko">
        <a href="Miko.php">Figurine kaguya-sama, Iino Miko</a><br>
        
        <p class="Prix" style="margin: 50px; ;">500€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Figurines/Nishizumi.png" alt="Nishizumi">
        <a href="Nishizumi_Miho.php">Miho Nishizumi Figurine</a><br>
        
        <p class="Prix" style="margin: 50px; ;">89€</p>
    </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Figurines/Ichika.png" alt="Ichika">
        <a href="https://www.shin-sekai.fr/the-quintessential-quintuplets/10625-the-quintessential-quintuplets-figurine-ichika-nakano--4580416942607.html">Ichika Nakano Figurine</a><br>
        
        <p class="Prix" style="margin: 50px; ;">-100€</p>
    </div> </div><br><br><br><br><br><br>

	<div class="Produits">
        <img src="Photos/Figurines/Nino.png" alt="Nino">
        <a href="https://chocolissimo.fr/do/item/3837-PLXXXX/6-Cupcakesde-Noel-en-chocolat?gclid=CjwKCAiAheacBhB8EiwAItVO22Uf8xFFJQvB35YmUFQz_MrAP48AcW9yPpiQxilPCTZ3uebpEli3MxoChRQQAvD_BwE">Nino Nakano Figurine</a><br>
       
        <p class="Prix" style="margin: 50px; ;">-100€</p>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>

		</div>
		<!--Mes Réseaux-->
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="../Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>
    



        