<!DOCTYPE html>
<!-- Titre et lien vers le CSS -->
<head>
	<title>Shopping Drop</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<!-- Corps du programme-->
<body>
	<?php include("header.php")?>
	<?php include("nav.php")?>
	<!--Timer-->
    <div id="timer">
		<script src="timer.js"> </script>
    </div>
	<!--Section contenant les images du produits-->
    <div class="important">
        <div class="images">
            <img src="Photos/PC/Asus/ASUSTUFA15-TUF507RR-HN076W.png" alt="ASUS"><br>
			<img src="Photos/PC/Asus/Asus1.png" alt="ASUS">
			<img src="Photos/PC/Asus/Asus2.png" alt="ASUS">
            <img src="Photos/PC/Asus/Asus3.png" alt="ASUS">
            <img src="Photos/PC/Asus/Asus4.png" alt="ASUS">
            <img src="Photos/PC/Asus/Asus5.png" alt="ASUS">
        </div>
		<!--Section contenant le nom, le prix et la description produit ainsi que un bouton pour acheter le produit-->
        <div class="description">
            <table class="tableau">
                <tr>
					<td><h1>ASUS TUF A15-TUF507RR-HN076W</h1></td>
				</tr>
				<tr>
					<td><h2>2000€</h2></td>
				</tr>
				<tr>
					<td>Nouveau processeur AMD Ryzen 7 6800H, 16 Go (2x barrettes 8 Go) de RAM DDR5-4800, 512Go SSD NVMe PCIe, écran 16:9 FHD 144 Hz.
                        Les graphismes du gameplay sont incroyablement fluides grâce à la carte graphique GeForce RTX 3070 8GB (8GB GDDR6) Grace son gros TGP de 140W (115W + 15W) , qui offre de manière fiable des taux d'images élevés dans de nombreux jeux modernes.
                        MUX Switch : dans le cadre des jeux compétitifs, vous pouvez passer à un mode GPU direct qui réduit la latence et augmente les performances de 5 à 10 % en moyenne.
                        Ventilateurs Arc Flow : chaque ventilateur comporte 84 pales qui varient en épaisseur à leur base pour brasser davantage d'air, elles sont recouvertes d'embouts spéciaux dont le design aérodynamique réduit les turbulences et le bruit générés.
                        Connectivité : Un port HDMI 2.0b dédié est complété par un USB Type-C avec prise en charge DisplayPort, 2x USB 3.2 Gen 1 Type A, 1x USB 3.2 Type C, 1x Combo Jack Audio. Le WiFi 6 (802.11ax) fournit des connexions rapides et fiables pour que vous restiez productif et compétitif en tous lieux, mais vous pouvez également vous connecter directement via le port Ethernet intégré.
                        Un mois d’abonnement Game Pass pour PC inclus à l’achat de votre appareil. N’oubliez pas de l’activer.</td>
				</tr>
				<tr>
					<td><a href="Acheter.php"><button>Acheter</button></a></td>
				</tr>
            </table>
        </div>
    </div>
<!--Contact-->
    <div class="Info">
		<div class="Contact">
			<h4>Contact</h4>
			<p>ShoppingDrop - Paris, France</p>
			<p>Email : info@ShoppingDrop.com</p>
			<p>Téléphone : 07 95 36 01 78</p>
<!--Mes Réseaux-->
		</div>
		<div class="Reseau">
			<h4>Rejoingnez-nous</h4>
			<a href="https://www.instagram.com/romain_ki/"><img src="../../Photos/Instagram.png" alt="Instagram"></a>
			<a href="https://www.twitch.tv/mast3rsushi"><img src="../../Photos/twitch.png" alt="Twitch"></a>
			<a href="https://www.youtube.com/channel/UCns1lzlWOTzujesi8O7IKiA"><img src="../../Photos/YouTube.png" alt="Youtube"></a>
			<p>Discord : Mast3rSushi#0023</p>
		</div>
	</div>
	<!--footer contenant le copyright-->
	<?php include("footer.php")?>
</body>
</html>