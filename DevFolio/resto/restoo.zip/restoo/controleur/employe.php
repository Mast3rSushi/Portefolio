<?php

if ($_SERVER["SCRIPT_FILENAME"] == __FILE__) {
    $racine = "..";
}
include_once "$racine/modele/bd.employer.info.inc.php"; // Inclure le modèle des employés
include_once "$racine/modele/authentification.inc.php";


if (isset($_GET["idEmploye"])) {
    $idEmploye = $_GET["idEmploye"];
    $employe = getEmployeInfoById($idEmploye);
    
    // Inclure la vue correspondante pour afficher les détails de l'employé
    $titre = "Détails de l'employé";
    include "$racine/vue/entete.html.php";
    include "$racine/vue/vueEmployeInfo.php"; // Créez cette vue pour afficher les détails de l'employé
    include "$racine/vue/pied.html.php";
}

?>
