<?php
include_once "bd.inc.php";

function getEmployesByIdR($idR) {
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("SELECT * FROM employe WHERE idR=:idR");
        $req->bindValue(':idR', $idR, PDO::PARAM_INT);
        $req->execute();

        $resultat = $req->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        print "Erreur : " . $e->getMessage();
        die();
    }

    return $resultat;
}

if ($_SERVER["SCRIPT_FILENAME"] == __FILE__) {
    // Programme principal de test
    header('Content-Type:text/plain');

    echo "\n getEmployesByIdR(1) : \n";
    print_r(getEmployesByIdR(1));

    echo "\n getEmployesByIdR(3) : \n";
    print_r(getEmployesByIdR(3));
}
?>
