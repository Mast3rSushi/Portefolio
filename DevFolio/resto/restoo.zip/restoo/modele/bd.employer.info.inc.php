<?php
include_once "bd.inc.php";

function getEmployeInfoById($idEmploye) {
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("SELECT * FROM employe WHERE idEmploye = :idEmploye");
        $req->bindValue(':idEmploye', $idEmploye, PDO::PARAM_INT);
        $req->execute();

        $resultat = $req->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        print "Erreur : " . $e->getMessage();
        die();
    }

    return $resultat;
}

if ($_SERVER["SCRIPT_FILENAME"] == __FILE__) {
    // Programme principal de test
    header('Content-Type:text/plain');

    echo "\n getEmployeInfoById(1) : \n";
    print_r(getEmployeInfoById(1));

    echo "\n getEmployeInfoById(3) : \n";
    print_r(getEmployeInfoById(3));
}
?>
