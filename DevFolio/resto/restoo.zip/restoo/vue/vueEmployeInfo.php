<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Informations sur l'employé</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .content {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="content">
        <?php
        if (isset($_GET['idEmploye'])) {
            $idEmploye = $_GET['idEmploye'];
            $cnx = connexionPDO();
            $req = $cnx->prepare("SELECT e.ageEmploye, e.nomEmploye, e.prenomEmploye, r.nomRole AS roleEmploye, e.portrait FROM employe e
            INNER JOIN role r ON e.idRole = r.idRole
            WHERE e.idEmploye = :idEmploye");

            $req->bindValue(':idEmploye', $idEmploye, PDO::PARAM_INT);
            $req->execute();
            $employeInfo = $req->fetch(PDO::FETCH_ASSOC);
        }

        if (isset($employeInfo) && !empty($employeInfo)) {
        ?>
        <h1>Informations sur l'employé</h1>
        <p><strong>Nom :</strong> <?= $employeInfo['nomEmploye'] ?></p>
        <p><strong>Prénom :</strong> <?= $employeInfo['prenomEmploye'] ?></p>
        <p><strong>Âge :</strong> <?= $employeInfo['ageEmploye'] ?></p>
        <p><strong>Rôle :</strong> <?= $employeInfo['roleEmploye'] ?></p>

        <?php
            $portraitFileName = $employeInfo['portrait'];
            $portraitPath = "images/portrait/$portraitFileName";

            if (file_exists($portraitPath)) {
        ?>
        <p><strong>Portrait :</strong></p>
        <img src="<?= $portraitPath ?>" alt="Portrait de <?= $employeInfo['nomEmploye'] ?>" width="200" height="200">
        <?php
            } else {
                echo "<p>Portrait introuvable</p>";
            }
        } else {
            echo "<p>Employé non trouvé</p>";
        }
        ?>
    </div>
</body>
</html>
