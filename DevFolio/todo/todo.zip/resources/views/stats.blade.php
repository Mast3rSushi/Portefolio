@extends("template")

@section("title", "Statistiques des Todos")

@section("content")
    <div class="container">
        <h1>Statistiques des Todos</h1>

        <ul>
            <li>Total des Todos : {{ $totalTodos }}</li>
            <li>Todos terminés : {{ $completedTodos }}</li>
            <li>Todos en cours : {{ $inProgressTodos }}</li>
            <li>Todos critiques : {{ $criticalTodos }}</li>
            <li>Todos non critiques : {{ $notCriticalTodos }}</li>
            <li>Todos supprimées : {{ $deletedTodos }}</li>
            <li>Total des tâches : {{ $totalTaches }}</li>
        </ul>
    </div>
@endsection
