<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('title')</title>
        @vite(['resources/js/app.js'])


        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>
    </head>
<body>
        <nav class="navbar navbar-expand-md navbar-dark bg-dark">
            <a class="navbar-brand" href="/">Ma Todo List</a>
            <a class="navbar-brand btn btn-primary" href="../liste"><i class="bi bi-app"></i>Liste</a>

            <a class="navbar-brand btn btn-danger" href="compteur">Compteur</a>

            <a class="navbar-brand btn btn-primary" href="{{ route('todo.search') }}">Chercher...</a>

        </nav>

        @yield('content')

        <a class="text-center" href="#"><br>Ma Todo List<br></a>
    <h1>Search Results</h1>

    <form action="{{ route('todo.search') }}" method="get">
        @csrf

        <label for="query">Search Text:</label>
        <input type="text" name="query" id="query" value="{{ request('query') }}">

        <p>Categories:</p>
        @foreach($categories as $category)
            <label>
                <input type="checkbox" name="categories[]" value="{{ $category->id }}" {{ in_array($category->id, request('categories', [])) ? 'checked' : '' }}>
                {{ $category->libelle }}
            </label>
        @endforeach

        <button type="submit">Search</button>
    </form>

    <ul>
        @forelse ($todos as $todo)
            <li>{{ $todo->texte }}</li>
        @empty
            <li>No results found</li>
        @endforelse
    </ul>
</body>
</html>