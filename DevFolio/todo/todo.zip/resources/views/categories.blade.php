@extends("template")

@section("title", "Categories")

@section("content")
    <div style="margin-bottom: 20px;">
        <h2>Catégories</h2>

        <!-- Affichage des catégories -->
        <ul style="list-style-type: none; padding: 0;">
            @foreach ($categories as $category)
                <li style="margin-bottom: 10px; border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
                    {{ $category->libelle }}
                    <form action="{{ route('categories.destroy', $category->id) }}" method="POST" style="display:inline; margin-left: 10px;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" style="background-color: #dc3545; color: #fff; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer;">Supprimer</button>
                    </form>
                </li>
            @endforeach
        </ul>

        <!-- Formulaire pour ajouter une catégorie -->
        <form action="{{ route('categories.store') }}" method="POST" style="margin-top: 20px;">
            @csrf
            <label for="libelle" style="display: block; margin-bottom: 10px;">Libellé :</label>
            <input type="text" name="libelle" required style="padding: 5px; border-radius: 3px; border: 1px solid #ccc; margin-bottom: 10px;">
            <button type="submit" style="background-color: #28a745; color: #fff; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer;">Ajouter</button>
        </form>
    </div>
@endsection
