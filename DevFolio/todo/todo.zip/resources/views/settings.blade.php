<!-- resources/views/settings.blade.php -->

@extends("template")

@section("title", "Paramètres")

@section("content")
<div class="container">
    <div class="card">
        <div class="card-body">
            <h2>Paramètres</h2>
            
            <form>
                <div class="mb-3">
                    <label for="theme" class="form-label">Thème</label>
                    <select class="form-select" id="theme">
                        <option value="light">Clair</option>
                        <option value="dark">Sombre</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="language" class="form-label">Langue</label>
                    <select class="form-select" id="language">
                        <option value="fr">Français</option>
                        <option value="en">Anglais</option>
                        <!-- Ajoutez d'autres options de langue si nécessaire -->
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Enregistrer</button>
            </form>
        </div>
    </div>
</div>
@endsection
