<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title')</title>

    <!-- Bootstrap CSS -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    <!-- Vite -->
    <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>
    @vite(['resources/js/app.js'])
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="/">Ma Todo List</a>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link btn btn-primary" href="liste"><i class="bi bi-app"></i> Liste</a>
                </li>
                <a class="navbar-brand btn btn-danger" href="{{ route('todo.stats') }}">Compteur</a>
                <li class="navbar-nav">
                    <a class="navbar-brand btn btn-primary" href="{{ route('liste.index') }}">Genstion des listes</a>
                </li>
                <li class="navbar-nav">
                    <a class="navbar-brand btn btn-primary" href="{{ route('todo.search') }}">Chercher...</a>
                </li>
               

            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    @yield('content')
</div>

</body>
</html>
