@extends("template")

@section("title", "Liste de Todos")

@section('content')

    <div class="container">
        <h2>Liste des éléments</h2>

        <!-- Formulaire pour ajouter une nouvelle liste -->
        <form action="{{ route('liste.createListe') }}" method="POST" class="mb-4">
    @csrf
    <div class="input-group">
        <span class="input-group-addon" id="basic-addon1"><span class="oi oi-plus"></span></span>
        <input id="nom" name="nom" type="text" class="form-control"
            placeholder="Ajouter une nouvelle liste..." aria-label="Nouvelle liste"
            aria-describedby="basic-addon1">
        <div class="input-group-append">
            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i></button>
        </div>
    </div>
    </form>

        <ul class="list-group">
            @forelse ($listes as $liste)
                <li class="list-group-item">{{ $liste->nom }}</li>
            @empty
                <li class="list-group-item">Aucune liste disponible.</li>
            @endforelse
        </ul>
    </div>

@endsection