@extends("template")

@if (session('message'))
<div class="alert alert-danger">
    {{ session('message') }}
</div>
@endif
@section("title", "Ma Todo List")

@section("content")
<div class="container mt-4">
    <div class="card">
        <div class="card-body">
            <h2 class="mb-4">Ma Todo List</h2>

            <!-- Formulaire pour ajouter une nouvelle tâche -->
            <form action="{{ route('todo.save') }}" method="POST" class="mb-4">
                @csrf
                <div class="input-group">
                    <span class="input-group-addon" id="basic-addon1"><span class="oi oi-pencil"></span></span>
                    <input id="texte" name="texte" type="text" class="form-control"
                        placeholder="Ajouter une nouvelle tâche..." aria-label="Nouvelle tâche"
                        aria-describedby="basic-addon1">

                    <div class="form-group">

                        <label>Catégories</label>
                        @foreach($categories as $categorie)
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="categories[]"
                                value="{{ $categorie->id }}">
                            <label class="form-check-label">{{ $categorie->libelle }}</label>
                        </div>
                        @endforeach
                    </div>

                    <div class="input-group-append">
                        <div class="priority-choice btn-group">
                            <input type="radio" name="priority" id="highpr" value="0" checked class="btn-check"><label
                                for="highpr" class="btn btn-outline-primary"><i class="bi bi-reception-1"></i></label>
                            <input type="radio" name="priority" id="lowpr" value="1" class="btn-check"><label
                                for="lowpr" class="btn btn-outline-danger"><i class="bi bi-reception-4"></i></label>
                            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i></button>
                        </div>
                    </div>
                </div>
            </form>





            <!-- Liste des tâches -->
            <ul class="list-group">
                @forelse ($todos as $todo)
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>
                        @if ($todo->important == 0)
                        <i class="bi bi-reception-1"></i>
                        @elseif ($todo->important == 1)
                        <i class="bi bi-reception-4"></i>
                        @endif
                        {{ $todo->texte }}
                    </span>
                    <!-- Affichage du texte -->

                    <!-- Affichage de la catégorie -->
                    <p>Catégories :</p>
                    <ul>
                        @foreach($todo->categories as $category)
                        <li>{{ $category->libelle }}</li>
                        @endforeach
                    </ul>
                    </p>
                    <div class="btn-group" role="group">
                        @if ($todo->termine === 0)
                        <a href="{{ route('todo.done', ['id' => $todo->id]) }}" class="btn btn-success"><i
                                class="bi bi-bag-check"></i></a>
                        @elseif ($todo->termine === 1)
                        <a href="{{ route('todo.delete', ['id' => $todo->id]) }}" class="btn btn-danger"><i
                                class="bi bi-trash3"></i></a>
                        @endif
                        @if ($todo->important == 0)
                        <a href="{{ route('todo.raise', ['id'=> $todo->id]) }}" class="btn btn-outline-secondary"><i
                                class="bi bi-arrow-up-circle"></i></a>
                        @elseif ($todo->important == 1)
                        <a href="{{ route('todo.lower', ['id' => $todo->id]) }}" class="btn btn-outline-secondary"><i
                                class="bi bi-arrow-down-circle"></i></a>
                        @endif
                    </div>
                </li>
                @empty
                <li class="list-group-item text-center">C'est vide !</li>
                @endforelse
            </ul>

        </div>
    </div>
    @endsection