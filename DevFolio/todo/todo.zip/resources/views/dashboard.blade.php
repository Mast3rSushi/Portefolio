<!-- resources/views/dashboard.blade.php -->

@extends("template")

@section("title", "Tableau de Bord")

@section("content")
<div class="container">
    <div class="card">
        <div class="card-body">
            <h2>Tableau de Bord</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Tâches à Faire</h5>
                            <p class="card-text">Nombre de tâches à faire : {{ $todos->where('termine', 0)->count() }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Tâches Terminées</h5>
                            <p class="card-text">Nombre de tâches terminées : {{ $todos->where('termine', 1)->count() }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-warning mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Tâches Critiques</h5>
                            <p class="card-text">Nombre de tâches critiques : {{ $todos->where('important', 1)->count() }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
