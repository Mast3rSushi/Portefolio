<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TodosTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('todos')->insert([
            'texte' => 'seed todos',
            'termine' => false,
            'important' => true,
            
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('todos')->insert([
            'texte' => 'wesh',
            'termine' => false,
            'important' => true,
            
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Ajoutez plus de tâches si nécessaire
    }
}