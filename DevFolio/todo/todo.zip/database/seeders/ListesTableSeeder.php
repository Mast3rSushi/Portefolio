<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ListesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       // Supprime toutes les entrées existantes dans la table
       DB::table('listes')->truncate();

       // Ajoute deux listes
       DB::table('listes')->insert([
           ['nom' => 'Liste 1'],
           ['nom' => 'Liste 2'],
       ]);
    }
}
