

<?php $__env->startSection("title", "Liste de Todos"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h2>Liste des éléments</h2>

        <!-- Formulaire pour ajouter une nouvelle liste -->
        <form action="<?php echo e(route('liste.createListe')); ?>" method="POST" class="mb-4">
    <?php echo csrf_field(); ?>
    <div class="input-group">
        <span class="input-group-addon" id="basic-addon1"><span class="oi oi-plus"></span></span>
        <input id="nom" name="nom" type="text" class="form-control"
            placeholder="Ajouter une nouvelle liste..." aria-label="Nouvelle liste"
            aria-describedby="basic-addon1">
        <div class="input-group-append">
            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i></button>
        </div>
    </div>
    </form>

        <ul class="list-group">
            <?php $__empty_1 = true; $__currentLoopData = $listes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item"><?php echo e($liste->nom); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item">Aucune liste disponible.</li>
            <?php endif; ?>
        </ul>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\todo2024_version2\resources\views/liste.blade.php ENDPATH**/ ?>