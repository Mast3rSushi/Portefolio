

<?php if(session('message')): ?>
<div class="alert alert-danger">
    <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
<?php $__env->startSection("title", "Ma Todo List"); ?>

<?php $__env->startSection("content"); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-body">
            <h2 class="mb-4">Ma Todo List</h2>

            <!-- Formulaire pour ajouter une nouvelle tâche -->
            <form action="<?php echo e(route('todo.save')); ?>" method="POST" class="mb-4">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <span class="input-group-addon" id="basic-addon1"><span class="oi oi-pencil"></span></span>
                    <input id="texte" name="texte" type="text" class="form-control"
                        placeholder="Ajouter une nouvelle tâche..." aria-label="Nouvelle tâche"
                        aria-describedby="basic-addon1">

                    <div class="form-group">

                        <label>Catégories</label>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="categories[]"
                                value="<?php echo e($categorie->id); ?>">
                            <label class="form-check-label"><?php echo e($categorie->libelle); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="input-group-append">
                        <div class="priority-choice btn-group">
                            <input type="radio" name="priority" id="highpr" value="0" checked class="btn-check"><label
                                for="highpr" class="btn btn-outline-primary"><i class="bi bi-reception-1"></i></label>
                            <input type="radio" name="priority" id="lowpr" value="1" class="btn-check"><label
                                for="lowpr" class="btn btn-outline-danger"><i class="bi bi-reception-4"></i></label>
                            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i></button>
                        </div>
                    </div>
                </div>
            </form>





            <!-- Liste des tâches -->
            <ul class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span>
                        <?php if($todo->important == 0): ?>
                        <i class="bi bi-reception-1"></i>
                        <?php elseif($todo->important == 1): ?>
                        <i class="bi bi-reception-4"></i>
                        <?php endif; ?>
                        <?php echo e($todo->texte); ?>

                    </span>
                    <!-- Affichage du texte -->

                    <!-- Affichage de la catégorie -->
                    <p>Catégories :</p>
                    <ul>
                        <?php $__currentLoopData = $todo->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($category->libelle); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    </p>
                    <div class="btn-group" role="group">
                        <?php if($todo->termine === 0): ?>
                        <a href="<?php echo e(route('todo.done', ['id' => $todo->id])); ?>" class="btn btn-success"><i
                                class="bi bi-bag-check"></i></a>
                        <?php elseif($todo->termine === 1): ?>
                        <a href="<?php echo e(route('todo.delete', ['id' => $todo->id])); ?>" class="btn btn-danger"><i
                                class="bi bi-trash3"></i></a>
                        <?php endif; ?>
                        <?php if($todo->important == 0): ?>
                        <a href="<?php echo e(route('todo.raise', ['id'=> $todo->id])); ?>" class="btn btn-outline-secondary"><i
                                class="bi bi-arrow-up-circle"></i></a>
                        <?php elseif($todo->important == 1): ?>
                        <a href="<?php echo e(route('todo.lower', ['id' => $todo->id])); ?>" class="btn btn-outline-secondary"><i
                                class="bi bi-arrow-down-circle"></i></a>
                        <?php endif; ?>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item text-center">C'est vide !</li>
                <?php endif; ?>
            </ul>

        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\todo2024_version2\resources\views/home.blade.php ENDPATH**/ ?>