<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>


        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    </head>
<body>
        <nav class="navbar navbar-expand-md navbar-dark bg-dark">
            <a class="navbar-brand" href="/">Ma Todo List</a>
            <a class="navbar-brand btn btn-primary" href="../liste"><i class="bi bi-app"></i>Liste</a>

            <a class="navbar-brand btn btn-danger" href="compteur">Compteur</a>

            <a class="navbar-brand btn btn-primary" href="<?php echo e(route('todo.search')); ?>">Chercher...</a>

        </nav>

        <?php echo $__env->yieldContent('content'); ?>

        <a class="text-center" href="#"><br>Ma Todo List<br></a>
    <h1>Search Results</h1>

    <form action="<?php echo e(route('todo.search')); ?>" method="get">
        <?php echo csrf_field(); ?>

        <label for="query">Search Text:</label>
        <input type="text" name="query" id="query" value="<?php echo e(request('query')); ?>">

        <p>Categories:</p>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label>
                <input type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>" <?php echo e(in_array($category->id, request('categories', [])) ? 'checked' : ''); ?>>
                <?php echo e($category->libelle); ?>

            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit">Search</button>
    </form>

    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li><?php echo e($todo->texte); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>No results found</li>
        <?php endif; ?>
    </ul>
</body>
</html><?php /**PATH C:\wamp64\www\todo2024_version2\resources\views/search-results.blade.php ENDPATH**/ ?>