

<?php $__env->startSection("title", "Statistiques des Todos"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container">
        <h1>Statistiques des Todos</h1>

        <ul>
            <li>Total des Todos : <?php echo e($totalTodos); ?></li>
            <li>Todos terminés : <?php echo e($completedTodos); ?></li>
            <li>Todos en cours : <?php echo e($inProgressTodos); ?></li>
            <li>Todos critiques : <?php echo e($criticalTodos); ?></li>
            <li>Todos non critiques : <?php echo e($notCriticalTodos); ?></li>
            <li>Todos supprimées : <?php echo e($deletedTodos); ?></li>
            <li>Total des tâches : <?php echo e($totalTaches); ?></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\todo2024_version2\resources\views/stats.blade.php ENDPATH**/ ?>