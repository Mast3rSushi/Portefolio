<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Vite -->
    <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="/">Ma Todo List</a>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link btn btn-primary" href="liste"><i class="bi bi-app"></i> Liste</a>
                </li>
                <a class="navbar-brand btn btn-danger" href="<?php echo e(route('todo.stats')); ?>">Compteur</a>
                <li class="navbar-nav">
                    <a class="navbar-brand btn btn-primary" href="<?php echo e(route('liste.index')); ?>">Genstion des listes</a>
                </li>
                <li class="navbar-nav">
                    <a class="navbar-brand btn btn-primary" href="<?php echo e(route('todo.search')); ?>">Chercher...</a>
                </li>
               

            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH C:\wamp64\www\todo2024_version2\resources\views/template.blade.php ENDPATH**/ ?>