<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\TodosController;
use App\Http\Controllers\ListeController;
use App\Http\Controllers\CategoriesController;

Route::get('/liste', [TodosController::class, 'liste'])->name('todo.liste');
Route::get('/', [TodosController::class, 'liste'])->name('todo.liste');
Route::get('/todos/compteur',[TodosController::class, 'stats'])->name('todo.stats');
Route::get('/liste', [ListeController::class, 'index'])->name('liste.index');
Route::post('/liste', [ListeController::class, 'createListe'])->name('liste.createListe');
//route home
Route::controller(TodosController::class)->group(function () {
Route::post('/action/add', [TodosController::class, 'saveTodo'])->name('todo.save');
Route::get('/action/done/{id}', [TodosController::class, 'done'])->name('todo.done');
Route::get('/action/lower/{id}', [TodosController::class, 'lower'])->name('todo.lower');
Route::get('/todo/raise/{id}', [TodosController::class, 'raise'])->name('todo.raise');
Route::get('/action/delete/{id}', [TodosController::class, 'deleteTodo'])->name('todo.delete');
Route::get('/todos/search', [TodosController::class, 'search'])->name('todo.search');
});
