<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categories;


class CategorieController extends Controller
{
/**
 * Affiche la liste des catégories.
 *
 *
 */
public function listeCatégories()
{
    return view("home", ["categories" => Categories::all()]);
}
}
