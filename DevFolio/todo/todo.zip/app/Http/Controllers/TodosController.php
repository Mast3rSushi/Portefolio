<?php

namespace App\Http\Controllers;
use App\Models\Todos;
use App\Models\Categories;

use Illuminate\Http\Request;

class TodosController extends Controller
{
    public function liste(){
        return view("home", ["todos" => Todos::all(), "categories" => Categories::all()]);
    }

    public function search(Request $request)
{
    $query = $request->input('query');
    $categories = $request->input('categories');

    $todos = Todos::where('texte', 'like', '%' . $query . '%');

    if ($categories) {
        $todos->whereHas('categories', function ($query) use ($categories) {
            $query->whereIn('id', $categories);
        });
    }

    $todos = $todos->get();

    return view('search-results', [
        'todos' => $todos,
        'categories' => Categories::all(), // Vous pouvez ajuster ceci si nécessaire
    ]);
}

    function saveTodo(Request $request){
    $texte = $request->input('texte');
    $button = $request->input('priority');
    $cats= $request->input('categories');

    if($texte){
        $todo = new Todos();
        $todo->texte = $texte;
        $todo->termine = 0;
        #Gestion du bouton Important
        if($button=='1'){
            $todo->Important = 1;
        } elseif($button=='0'){
            $todo->Important = 0;
        }
        $todo->save();
        $todo->categories()->attach($cats); /*A ajouter */
        return redirect()->route('todo.liste');
    } else{
        return redirect()->route('todo.liste')->with('message', "Veuillez saisir une note à ajouter");
    }
    }
    function lower($id) {
        $todo = Todos::find($id);
        if (!$todo) {
            return redirect()->route('todo.liste')->with('message', "La tâche n'a pas été trouvée");
        }
        // Logique pour descendre la priorité de la tâche
        $todo->important = $todo->important == 0 ? 1 : 0;
        $todo->save();

        return redirect()->route('todo.liste');
    }
    function raise($id)
    {
        $todo = Todos::find($id);
        if (!$todo) {
            return redirect()->route('todo.liste')->with('message', "La tâche n'a pas été trouvée");
        }
        $todo->important = $todo->important == 1 ? 0 : 1;
        $todo->save();
        return redirect()->route('todo.liste');
    }

    function done($id)
    {
        $todo = Todos::find($id);
        if (!$todo) {
            return redirect()->route('todo.liste')->with('message', "La tâche n'a pas été trouvée");
        }
        $todo->termine = 1;
        $todo->save();

        return redirect()->route('todo.liste');
    }
    function deleteTodo($id)
    {
        $todo = Todos::find($id);
        if (!$todo) {
            return redirect()->route('todo.liste')->with('message', "La tâche n'a pas été trouvée");
        }
        $todo->delete();
        return redirect()->route('todo.liste')->with('validation', "La tâche a été supprimée avec succès");
    }








        function stats()
    {
        $totalTodos = Todos::count();
        $completedTodos = Todos::where('termine', 1)->count();
        $inProgressTodos = Todos::where('termine', 0)->count();
        $criticalTodos = Todos::where('important', 1)->count();
        $notCriticalTodos = Todos::where('important', 0)->count();
        $deletedTodos = Todos::onlyTrashed()->count();
        $totalTaches = Todos::withTrashed()->count();

        return view('stats', compact('totalTodos', 'completedTodos', 'inProgressTodos', 'criticalTodos', 'notCriticalTodos','deletedTodos','totalTaches'));
    }





        function dashboard()
    {
        $todos = Todos::all();
        return view("dashboard", compact('todos'));
    }




    
        function settings()
    {
        // Logique pour récupérer les paramètres
        return view("settings");
    }

}

