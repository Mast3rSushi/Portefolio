<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Liste;

class ListeController extends Controller
{
    public function index()
    {
        $listes = Liste::all();

        return view('liste',compact('listes'));
    }

    public function createListe(Request $request)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
        ]);

        // Créez une nouvelle liste
        Liste::create([
            'nom' => $request->input('nom'),
        ]);

        return redirect()->route('liste.index')->with('success', 'Liste ajoutée avec succès.');
    }
}