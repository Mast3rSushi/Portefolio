# -*- coding: utf-8 -*-
"""
Created on Mon Jan  9 18:01:22 2023

@author: SOPHIE
"""
import json
import random
# Simple quiz en utilisant les dictionnaires


#Fonction permettant de faire le choix du thème à utiliser lors du quizz
def choix() :
    print("Veuillez choisir un quizz :"" 1- Les tornades "" 2- L'espace")
    global a
    a = int(input("Rentrez 1 ou 2 : "))
    while a != 1 or a !=2 :
        if a == 1 or a == 2 :
            break 
        else : 
            print("Rentrez un numéro de quizz valide !")      
            print("Veuillez choisir un quizz :"" 1- Les tornades "" 2- L'espace")
            a = int(input("Rentrez 1 ou 2 : "))
    return(a)


def main():
    global nbrQuestion
    global x
    global questions
    global data
    if a == 1 :
        with open("F:\BTS/AP_QUIZZ/reel/questions/Tornade.json","r", encoding="utf8") as file:
            data = json.load(file)
        questions = list(data.keys())
        x = int(input("Combien de questions voulez vous ?"))
        #Si le thème 1 est choisi, on va chercher le fichier json correspondant et on demande au joueur combien de question il veut

        print ("*** Début du Quiz ***\n")
        nom = input (" Entrez votre nom: ").title()
        while nom == "" :
            if nom != "":
                break
            else :
                print("Veuillez saisir un nom : ")
                nom = input (" Entrez votre nom: ").title()
        print ()
        #Boucle demandant de resaisir un nom si celui-ci n'est pas valide
        print("\nBien joué {0}, vous avez repondu correcte à {1} de {2} questions.".format(nom, quiz(questions), x))
        print("Voulez-vous relancer un Quizz ?")
        raiponse = input("[o/n]")
        while raiponse == "o":
            choix()
            nbrQuestion = 0
            
            main()
            if raiponse == "o" :
                break
        #Boucle permettant de relancer un quizz
    elif a == 2 :
        
        with open("F:\BTS/AP_QUIZZ/reel/questions/Espace.json","r", encoding="utf8") as file:
            data = json.load(file)
        
        questions = list(data.keys())
        
        x = int(input("Combien de questions voulez vous ?"))
        #Si le thème 2 est choisi, on va chercher le fichier json correspondant et on demande au joueur combien de question il veut

        print ("*** Début du Quiz ***\n")
        nom = input (" Entrez votre nom: ").title()
        while nom == "" :
            if nom != "":
                break
            else :
                print("Veuillez saisir un nom : ")
                nom = input (" Entrez votre nom: ").title()
        print ()
        #Boucle demandant de resaisir un nom si celui-ci n'est pas valide
        print("\nBien joué {0}, vous avez repondu correcte à {1} de {2} questions.".format(nom, quiz(questions), x))
        print("Voulez-vous relancer un Quizz ?")
        raiponse = input("[o/n]")
        
        #Boucle permettant de relancer un quizz
        while raiponse == "o":
            choix()
            nbrQuestion = 0
           
            main()
            if raiponse == "o" :
                break
        
    
def quiz(qs):
    global x
    global nbrQuestion
    #Fonction de quizz et calcul des points.
    #Paramètre d'entree : sc : types Dictionnaitre
    #Praramètre de sortie :
    random.shuffle(qs)
    #Fonction qui mélange les questions
    points = 0
    for qu in qs[:x]: #qs. Item 
        nbrQuestion +=1
        answer = input(qu + "?")
        if answer == data[qu]:
            points += 1
            print("Bonne réponse !")
        else:
            print("Oups, la bonne réponse est \"{}\".".format(data[qu]))
        if nbrQuestion ==x :
            break    
    return points
global Qtornade
global QEspace

if __name__ == "__main__":
    choix()
    nbrQuestion = 0
    
    main()

    """"http://ecole2chenes.free.fr/travaux/annee2003_2004/univers/qcm.htm"""

