# -*- coding: utf-8 -*-
"""
Created on Mon Jan  9 18:01:22 2023

@author: SOPHIE
"""
import json
import random
# Simple quiz en utilisant les dictionnaires


# Fonction permettant de faire le choix du thème à utiliser lors du quizz
def choix():
    print("Veuillez choisir un quizz :"" 1- Les tornades "" 2- L'espace")
    global a
    a = (input("Rentrez 1 ou 2 : "))
    while a != "1" or a != "2":
        if a == "1" or a == "2":
            break
        else:
            print("Rentrez un numéro de quizz valide !")
            print("Veuillez choisir un quizz :"" 1- Les tornades "" 2- L'espace")
            a = (input("Rentrez 1 ou 2 : "))
    return (a)


def main():
    global nbrQuestion
    global x
    global questions
    global data


    if a == "1":
        with open("questions\Tornade.json", "r", encoding="utf8") as file:
            data = json.load(file)
    # On crée une liste des questions dans le fichier JSON.
        questions = list(data.keys())
        x = int(input("Combien de questions voulez vous ?"))
        while x > 10 :
            print("Le quizz ne contient pas plus de 10 questions !")
            x = int(input("Combien de questions voulez vous ?"))
            if x <= 10 :
                break
        print("*** Début du Quiz ***\n")
        nom = input("Entrez votre nom: ").title()

    # On utilise une boucle "while" pour demander à l'utilisateur de saisir un nom valide.
        while nom == "":
            if nom != "":
                break
            else:
                print("Veuillez saisir un nom : ")
                nom = input(" Entrez votre nom: ").title()
        print()

    # On appelle la fonction "quiz" pour lancer le quiz, et on affiche le nombre de bonnes réponses.
        print("\nBien joué {0}, vous avez repondu correcte à {1} de {2} questions.".format(
            nom, quiz(questions), x))
        print("Voulez-vous relancer un Quizz ?")
        raiponse = input("[o/n]")

    # On utilise une boucle "while" pour permettre à l'utilisateur de relancer le quiz autant de fois qu'il le souhaite.
        while raiponse == "o":
        # On appelle la fonction "choix" pour afficher le menu principal.
            choix()
            nbrQuestion = 0  # On réinitialise le nombre de questions posées.
            main()  # On appelle la fonction "main" pour lancer le quiz.

        # On utilise une condition pour sortir de la boucle si l'utilisateur ne veut plus relancer le quiz.
            if raiponse == "o":
                break

    # Choix n°2
    elif a == "2":

        with open("questions\Espace.json", "r", encoding="utf8") as file:
            data = json.load(file)

        questions = list(data.keys())

        x = int(input("Combien de questions voulez vous ?"))
        while x > 10 :
            print("Le quizz ne contient pas plus de 10 questions enculé de ta mère !")
            x = int(input("Combien de questions voulez vous ?"))
            if x <= 10 :
                break
        # Si le thème 2 est choisi, on va chercher le fichier json correspondant et on demande au joueur combien de question il veut

        print("*** Début du Quiz ***\n")
        nom = input(" Entrez votre nom: ").title()
        while nom == "":
            if nom != "":
                break
            else:
                print("Veuillez saisir un nom : ")
                nom = input(" Entrez votre nom: ").title()
        print()
        # Boucle demandant de resaisir un nom si celui-ci n'est pas valide
        print("\nBien joué {0}, vous avez repondu correcte à {1} de {2} questions.".format(
            nom, quiz(questions), x))
        print("Voulez-vous relancer un Quizz ?")
        raiponse = input("[o/n]")
        while raiponse == "o":
            choix()
            nbrQuestion = 0

            main()
            if raiponse == "o":
                break
        # Boucle permettant de relancer un quizz


def quiz(qs):
    global x
    global nbrQuestion
    # Fonction de quizz et calcul des points.
    # Paramètre d'entree : sc : types Dictionnaitre
    # Praramètre de sortie :
    random.shuffle(qs)
    # Fonction qui mélange les questions
    points = 0
    for qu in qs[:x]:
        nbrQuestion += 1
        # On demande à l'utilisateur de répondre à la question, et on stocke la réponse dans la variable "answer".
        answer = input(qu + "?")
    
        # On vérifie si la réponse de l'utilisateur correspond à la réponse stockée dans le dictionnaire "data".
        if answer == data[qu]:
            points += 1 # On incrémente le nombre de points si la réponse est correcte.
            print("Bonne réponse !")
        else:
            # On affiche la bonne réponse si la réponse de l'utilisateur est incorrecte.
            print("Oups, la bonne réponse est \"{}\".".format(data[qu]))
    
        # On utilise une condition pour sortir de la boucle si on a posé le nombre de questions demandé.
        if nbrQuestion == x:
            break

    # On retourne le nombre de points obtenus à la fin du quiz.
    return points


global Qtornade
global QEspace

if __name__ == "__main__":
    choix()
    nbrQuestion = 0
    main()
