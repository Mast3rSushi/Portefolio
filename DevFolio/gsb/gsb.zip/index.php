<!DOCTYPE html>
<html>
<head>
	<title>Connexion</title>
	<link rel="icon" href="images/favicon.ico" />
	<link href="connexion.css" rel="stylesheet"/>
</head>
<body>
<div class="but">
<img src="images/gsb.png" alt="logoGsb">
			<br />	
			<br />
			<br />	
			<br />
			<br />	
			<br />
	<legend><i>Identifiez-vous</i></legend>
	<form method="post" action="verif.php">
		<p>
			<label class="label1" for="pseudo">Votre nom: &nbsp;</label>&nbsp;
			<input class="zone" type="text" name="pseudo" id="pseudo"/>

			<br />	
			<br />
			<label class="label2" for="pass">Votre code secret: &nbsp;</label>&nbsp;
			<input class="zone" type="password" name="pass" id="pass" placeholder="Format: AAAA-MM-JJ" size="" maxlength="20" />

			
			<br />
			<br />
			<br />
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn">Valider</button>
		</p>
	</form>
</div>
</body>
</html>