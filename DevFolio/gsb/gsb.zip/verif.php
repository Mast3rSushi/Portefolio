
<?php

function encrypt($pure_string, $encryption_key) {
	$iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
	$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
	$encrypted_string = mcrypt_encrypt(MCRYPT_BLOWFISH, $encryption_key, utf8_encode($pure_string), MCRYPT_MODE_ECB, $iv);
	return $encrypted_string;
}

try {
    $bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', ''); //Connexion à la bdd
} catch (Exception $e){
    die('Erreur : '.$e->getMessage()); //Affiche le message de l'erreur
}

$req = $bdd->prepare('SELECT VIS_NOM FROM visiteur WHERE VIS_NOM = :pseudo AND VIS_DATEEMBAUCHE  = :pass');
$req->execute(array('pseudo' => $_POST['pseudo'], 'pass' => $_POST['pass']));

$resultat = $req->fetch();

if (!$resultat) {
    echo 'Mauvais identifiant ou mot de passe !<br/>';
    echo "<a href=index.php>Retour</a>";
} else {
    session_start();
    $_SESSION['Nom'] = $_POST['pseudo'];
    $messageAChiffrer = $_POST['pass'];
    $cleSecrete = 'gsbAIleDeMort';
    //$motdepasse = encrypt($messageAChiffrer, $cleSecrete);
    include('gsb.php');

}
?>