<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="icon" href="images/favicon.ico" />
</head>
<body>

<form action="cible_csv.php" method="POST">
  <p>Vous pouvez importer des praticiens à partir d'un fichier au format CSV</p>
   <p>
     <input name="file" type="file" />
  </p>
   <p><input type="submit" value="Envoyez le fichier" /></p>


</form>

</body>
</html>