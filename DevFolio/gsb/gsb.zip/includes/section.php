<!DOCTYPE html>
<!-- Section -->
								<section>
									<header class="major">
										<h2>Comment ça marche</h2>
									</header>
									<div class="posts">
										<article>
											<a href="tuto_rapport.php" class="image"><img src="images/logo_rapport.png" alt="" /></a>
											<h3>Gestion des comptes rendu</h3>
											<p>Grace à l'application web galaxy swiss bourdin il vous sera possible den remplir vos comptres rendu de visites.</p>
										</article>
										<article>
											<a href="tuto_import" class="image"><img src="images/logo_import.png" alt="" /></a>
											<h3>Importer des visiteurs</h3>
											<p>Il vous est également possible d'importer des visiteurs depuis un fichier Excel. selectionnez votre fichier .xlsx uniquement. L'importation est automatique.</p>
										</article>
										<article>
											<a href="tuto_pdf.php" class="image"><img src="images/logo_pdf.png" alt="Logo de pdf" height="280" /></a>
											<h3>Exporter en PDF</h3>
											<p>Vous pouvez également exporter un compte rendu en PDF afin de le concerver. pour celà il vous suffit de selectionner le rapport voulu ainsi que d'indiquer ou l'enregistrer.</p>
										</article>
									</div>
								</section>