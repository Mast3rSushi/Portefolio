<!DOCTYPE html>

<html>

	<head>

		<meta charset="utf-8">

		<title>Formulaire Praticien</title>

	</head>

	<body>


		<?php
			try{

				$bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', '');}

			catch (Exception $e){

				die('Erreur : ' . $e->getMessage());}

		?>

		<?php
		$reponse = $bdd->query('SELECT * FROM PRATICIEN');

		$donnees = $reponse->fetch();

		?>

		<form method="post" action="">

			<p>
				<label for="praticien">Selectionnez un praticien pour afficher ces infos</label>

				<select name="unPraticien" id="unPraticien">

					<?php 
					while ($donnees = $reponse->fetch())
					{
					echo '<option value='.'"'.$donnees['PRA_NOM'].'"'.'>'.$donnees['PRA_NOM']. " " .$donnees['PRA_PRENOM'] . '</option>';
					}?>
					?>
					<option value="Notini">Notini Alain</option>
				</select>

				<input type="submit" value="Choisir">

				<br/>

				<?php
				if (isset($_POST['unPraticien'])) {
					$reponse = $bdd->prepare('SELECT * FROM PRATICIEN INNER JOIN type_praticien ON PRATICIEN.TYP_CODE = type_praticien.TYP_CODE WHERE PRA_NOM = :nom;');
					$reponse->execute(array('nom' => $_POST['unPraticien'], ));
		
					$d = $reponse->fetch();
					echo "NUMERO : ".$d['PRA_NUM']."<br />NOM : ".$d['PRA_NOM']."<br />PRENOM : ".$d['PRA_PRENOM']."<br />ADRESSE : ".$d['PRA_ADRESSE']."<br />VILLE : ".$d['PRA_CP']." ".$d['PRA_VILLE']."<br />COEFICIENT NOTORIETE : ".$d['PRA_COEFNOTORIETE']."<br />LIEU D'EXERCICE : ".$d['TYP_LIBELLE'];
			} else {
				echo 'erreur de récupération des données';
			}

			?>

			</p>

		</form>

	</body>

</html>