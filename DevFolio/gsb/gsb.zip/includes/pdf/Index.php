<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8" />
        <title>>Export en pdf</title>
    </head>


    <body>

    <a href="pdf.php">Export en PDF</a>
    
    </body>
</html>