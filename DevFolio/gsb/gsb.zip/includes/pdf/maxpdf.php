<?php
require('tfpdf.php');

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

// Si tout va bien, on peut continuer

// On récupère tout le contenu des table
$requete = $bdd->query('SELECT MAX(RAP_NUM) AS RAP_NUM FROM rapport_visite;');
$max = $requete->fetch();
$num = $max['RAP_NUM'];

$requeteB = $bdd->prepare('SELECT * FROM rapport_visite WHERE RAP_NUM = :max');
$requeteB->execute(array('max' => $num));
$rap = $requeteB->fetch();

$praticien = $bdd->prepare('SELECT * FROM praticien WHERE PRA_NUM = :num');
$praticien->execute(array('num' => $num));
$pra = $praticien->fetch();

class PDF extends tFPDF
{
// En-tête
function Header()
{
	// Logo
	$this->Image('logo.png',10,6,30);
	// Police Arial gras 15
	$this->SetFont('Arial','B',15);
	// Décalage à droite
	$this->Cell(80);
	// Titre
	$this->Cell(62,10,'Compte rendu de Visite',1,0,'C');
	// Saut de ligne
	$this->Ln(20);
}

// Pied de page
function Footer()
{
	// Positionnement à 1,5 cm du bas
	$this->SetY(-15);
	// Police Arial italique 8
	$this->SetFont('Arial','I',8);
	// Numéro de page
	$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}


// Instanciation de la classe dérivée
$pdf = new tFPDF();
$pdf->AddPage();
// Ajoute une police Unicode (utilise UTF-8)
$pdf->AddFont('DejaVu','','DejaVuSansCondensed.ttf',true);
$pdf->SetFont('DejaVu','',14);
$pdf->Ln(5);
$pdf->Write(5,'Rapport N° '.$rap['RAP_NUM']." ".$pra['PRA_NOM']." ".$pra['PRA_PRENOM']);
$pdf->Ln(10);
$pdf->Write(5,'Date de Rapport : '.$rap['RAP_DATE']);
$pdf->Ln(10);
$pdf->Write(5,'Motif de la visite : '.$rap['RAP_MOTIF']);
$pdf->Ln(10);
$pdf->Write(5,'Bilan : '.$rap['RAP_BILAN']);
$pdf->Output();
?>