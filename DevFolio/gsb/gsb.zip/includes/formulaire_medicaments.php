<!DOCTYPE html>

<html>

	<head>

		<meta charset="utf-8">

		<title>Formulaire Medicament</title>

	</head>

	<body>

		<?php
			try{

				$bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', '');}

			catch (Exception $e){

				die('Erreur : ' . $e->getMessage());}

		?>

		<?php

			$reponse = $bdd->query('SELECT * FROM medicament');

			$donnees = $reponse->fetch();				

		?>


		<form method="post" action="">

			<p>
				<label for="Medicament">Selectionnez un médicament pour afficher ces infos</label>

				<select name="Medicament" id="Medicament">

					<?php 
					while ($donnees = $reponse->fetch())
					{
					echo '<option value='.'"'.$donnees['MED_NOMCOMMERCIAL'].'"'.">".$donnees['MED_NOMCOMMERCIAL']. " " . '</option>';
					}?>

				</select>

				<input type="submit" value="Choisir">


				<br/>

				<?php
					
					if (isset($_POST['Medicament'])) {
						$reponse = $bdd->prepare('SELECT * FROM medicament INNER JOIN famille ON medicament.FAM_CODE = famille.FAM_CODE WHERE MED_NOMCOMMERCIAL = :nom;');
						$reponse->execute(array('nom' => $_POST['Medicament'], ));
						$d = $reponse->fetch();
						echo "DEPOT LEGAL : ".$d['MED_DEPOTLEGAL']."<br />NOM : ".$d['MED_NOMCOMMERCIAL']."<br />FAMILLE : ".$d['FAM_LIBELLE']."<br />COMPOSITION : ".$d['MED_COMPOSITION']."<br />EFFETS : ".$d['MED_EFFETS']."<br />CONTRE INDICATION : ".$d['MED_CONTREINDIC']."<br />PRIX ECHANTILLON : ".$d['MED_PRIXECHANTILLON'];
					} else {
					
					}
				?>
			</p>	
		</form>

	</body>

</html>