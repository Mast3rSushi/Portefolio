<!DOCTYPE html>
<!-- Header -->
<header id="header">
<a href="gsb.php" class="logo"><strong>Galaxy Swiss Bourdin</strong></a>
<?php 
//session_start();
if (isset($_POST['pseudo'])) {
	echo "<strong>" .$_SESSION['Nom'] ."</strong>";
} else {
	session_start();
	if (isset($_SESSION['Nom'])) {

	echo "<strong>" .$_SESSION['Nom'] ."</strong>";
} else {
	echo '<a href="index.php">'."Connexion</a>";
}
}

?>

</header>
	