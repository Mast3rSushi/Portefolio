<!DOCTYPE html>

<html>

	<head>

		<meta charset="utf-8">

		<title>Formulaire Visiteur</title>
		<link rel="icon" href="images/favicon.ico" />
		

	</head>

	<body>

		<?php
			try{

				$bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', '');}

			catch (Exception $e){

				die('Erreur : ' . $e->getMessage());}

		?>

		<?php

			$reponse = $bdd->query('SELECT * FROM VISITEUR');

			$donnees = $reponse->fetch();				

		?>


		<form method="post" action="">

			<p>
				<label for="Visiteur">Selectionnez un visiteur pour afficher ces infos</label>

				<select name="Visiteur" id="Visiteur">

					<?php 
					while ($donnees = $reponse->fetch())
					{
					echo '<option value='.'"'.$donnees['VIS_NOM'].'"'.'>'.$donnees['VIS_NOM']. " " .$donnees['Vis_PRENOM'] . '</option>';
					}?>

				</select>

				<input type="submit" value="Choisir">


				<br/>

				<?php

					

				
					
					
					if (isset($_POST['Visiteur'])) {
						$reponse = $bdd->prepare('SELECT * FROM visiteur INNER JOIN labo ON visiteur.LAB_CODE = labo.LAB_CODE WHERE VIS_NOM = :nom;');
						$reponse->execute(array('nom' => $_POST['Visiteur'], ));
						$d = $reponse->fetch();
						echo "MATRICULE : ".$d['VIS_MATRICULE']."<br />NOM : ".$d['VIS_NOM']."<br />PRENOM : ".$d['Vis_PRENOM']."<br />ADRESSE : ".$d['VIS_ADRESSE']."<br />VILLE : ".$d['VIS_CP']." ".$d['VIS_VILLE']."<br />DATE EMBAUCHE : ".$d['VIS_DATEEMBAUCHE']."<br />SECTEUR : ".$d['SEC_CODE']."<br />LABO : ".$d['LAB_NOM']."<br />GENRE : ".$d['genre'];
					} else {
						
					}
				?>
			</p>	
		</form>

	</body>

</html>