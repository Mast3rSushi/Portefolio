<!DOCTYPE html>
<html>
<head>
	<title>Transfert de donnée</title>
</head>
<body>
<?php //connexion a la base de donée et création des requêtes.
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', '');
}
catch(Exception $e)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$e->getMessage());
}

// Si tout va bien, on peut continuer

// On récupère tout le contenu de la table jeux_video
$reponse = $bdd->query('SELECT * FROM praticien ORDER BY pra_nom;');
$requeteB = $bdd->query('SELECT * FROM medicament;');
$requeteC = $bdd->query('SELECT MAX(RAP_NUM) AS RAP_NUM FROM rapport_visite;');

?>

<p>Numéro de rapport : <?php $rap = $requeteC->fetch(); echo $rap['RAP_NUM']+1; ?></p>


<form action="cible.php" method="POST" name="compte_rendu">
	<label for="praticiens">Praticiens</label>
	<select name="praticiens">
	    <?php while ($pra = $reponse->fetch()) {
	    		echo "<option value=".$pra['PRA_NOM'].">".$pra['PRA_NOM']." ".$pra['PRA_PRENOM']."</option>";
	    }
	    ?>
	</select>
	<label>Date de rapport </label><input type="date" name="date_rapport"><br/>
	<label>Motif de la visite </label><input type="text" name="motif_visite"><br/>
	<label>Médicaments </label>
	<select name="medicaments">
	<?php while ($med = $requeteB->fetch()) {
	    		echo "<option value=".$med['MED_NOMCOMMERCIAL'].">".$med['MED_NOMCOMMERCIAL']."</option>";
	    }
	    ?>
	</select><br/>
	<label for="bilan_rapport">Bilan </label><textarea name="bilan_rapport"></textarea><br/>
	
	<input type="submit" name="Ajouter" >
	</form>
</body>
</html>