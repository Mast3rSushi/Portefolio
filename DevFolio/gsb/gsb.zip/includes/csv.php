<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
</head>
<body>

<form action="index.php?" method="POST">
  <p>Vous pouvez importer des visiteurs à partir d'un fichier au format CSV</p>
   <p>
     <input name="file" type="file" />
  </p>
   <p><input type="submit" value="Envoyez le fichier" /></p>


</form>

   <?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}







$row = 1;
if (($handle = fopen("visiteur.csv", "r")) !== FALSE){
    while (($data = fgetcsv($handle, 1000, ";")) !== FALSE){
        $num = count($data);
        echo "Contenu du fichier importer :"
       echo "<br /><br /><p> $num champs à la ligne $row:</p>";
        $row++;
        for ($c=0; $c < $num; $c++) {
           echo $data[$c] . " <br/>";
       		$req = $bdd->prepare("INSERT INTO vers(vers1) VALUES(:vers)");
			$req->execute(array('vers' => $data[$c]));

        }
    }
    fclose($handle);
  }
?>


</body>
</html>