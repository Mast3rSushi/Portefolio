<!DOCTYPE html>
<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								<section id="search" class="alt">
									<form method="post" action="recherche.php">
										<input type="text" name="query" id="query" placeholder="Rechercher" />
									</form>
								</section>

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>Menu</h2>
									</header>
									<ul>
										<li><a href="compte_rendu.php">Comptes rendus de visites</a></li>
										<li><a href="visiteurs.php">Visiteurs</a></li>
										<li><a href="praticiens.php">Praticiens</a></li>
										<li><a href="medicaments.php">Médicaments</a></li>
										<li><a href="import.php">Importer des visiteurs</a></li>
									</ul>
								</nav>
							<!-- Section -->
								<section>
									<header class="major">
										<h2>Contacter GSB</h2>
									</header>
									<p>Contacter nous a l'adresse suivantes :</p>
									<ul class="contact">
										<li class="fa-envelope-o"><a href="#">souffrance@gsb.fr</a></li>
										<li class="fa-phone">(+33)  80 00 15 65 98</li>
										<li class="fa-home">1234 Somewhere Road #8254<br />
										Paris, CEDEX 15</li>
										<li><a href="index.php">Déconnexion</a></li>
									</ul>
								</section>

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; Untitled. All rights reserved. Demo Images: <a href="https://unsplash.com">Unsplash</a>. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
								</footer>

						</div>
					</div>