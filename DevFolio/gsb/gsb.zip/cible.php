<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Galaxy Swiss Bourdin</title>
		<meta charset="utf-8" />
		<link rel="icon" href="images/favicon.ico" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
							<?php include("includes/header.php"); ?>

							<!-- Banner -->
								<section id="banner">
									<!--  Contenue de la page ici :  -->
									<div class="content">
										<header>
											<h1>Compte rendu ajouté</h1>
										</header>
										<?php
										try
										{
											// On se connecte à MySQL
											$bdd = new PDO('mysql:host=localhost;dbname=gsb;charset=utf8', 'root', '');
										}
										catch(Exception $e)
										{
											// En cas d'erreur, on affiche un message et on arrête tout
										        die('Erreur : '.$e->getMessage());
										}

										//Déclaration des variables nécessaire a l'entrée des données dans la base MySql.
										$pra_nom = $_POST['praticiens'];
										$date = $_POST['date_rapport'];
										$bilan = $_POST['bilan_rapport'];
										$motif = $_POST['motif_visite'];


										//Création des requêtes
										//$requeteMat = $bdd->query('SELECT VIS_MATRICULE FROM visiteur WHERE VIS_NOM = :matricule;');
										
										$requeteMat = $bdd->prepare('SELECT VIS_MATRICULE FROM visiteur WHERE VIS_NOM = :matricule;');
										$requeteMat->execute(array(
												'matricule' => $_SESSION['Nom'],
										));
										
										$requetePra_Num = $bdd->prepare('SELECT PRA_NUM FROM praticien WHERE PRA_NOM = :pra_nom');
											$requetePra_Num->execute(array(
												'pra_nom' => $pra_nom,
												));
										$requeteNumRap = $bdd->query('SELECT MAX(RAP_NUM) AS RAP_NUM FROM rapport_visite;');

										$mat = $requeteMat->fetch();
										$praNum =  $requetePra_Num->fetch();
										$rapNum =  $requeteNumRap->fetch();

										//On Insère les valeur dans un nouveau champ de la table rapport de visite.
											$req = $bdd->prepare('INSERT INTO rapport_visite (VIS_MATRICULE, PRA_NUM, RAP_NUM, RAP_DATE, RAP_BILAN, RAP_MOTIF) VALUES( :mat, :numPra, :numRap, :date_rap, :bilan, :motif)');
											$req->execute(array(
												'mat' => $mat['VIS_MATRICULE'],
												'numPra' => $praNum['PRA_NUM'],
												'numRap' => $rapNum['RAP_NUM']+1,
												'date_rap' => $date,
												'bilan' => $bilan,
												'motif' => $motif,
												));
											?>
											<img src="images/valide.png" height="150"><br/>
											<p>Rapport ajouté avec succès</p>
											
									<a href="includes/pdf/maxpdf.php" target="_blank"><input type="button" name="Export pdf" value="Export en PDF"></a>
									<a href="compte_rendu.php"><button id="Retour">Retour</button></a>
									</div>
									
								</section>

							<!-- Section -->
							<?php include("includes/section.php"); ?>
						</div>
					</div>

				<!-- Sidebar -->
				<?php include("includes/menu.php"); ?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
	</body>
</html>
